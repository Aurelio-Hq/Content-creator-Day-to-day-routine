---
name: project-packager
description: |
  Extrai, estrutura e empacota projetos caóticos (arquivos espalhados em /mnt/project/ ou múltiplas contas claude.ai) em repositórios GitHub production-ready com naming conventions, documentação automática, metadata estruturado YAML, e QA gates. Use SEMPRE quando o usuário pedir "empacota projeto", "estrutura repo", "prepara para GitHub", "normaliza arquivos", "package project", "gera ZIP estruturado", "organiza meus arquivos", "transforma isso em repo", ou quando mencionar arquivos em /mnt/project/ que precisam virar repositório. TAMBÉM ative automaticamente quando detectar múltiplos arquivos HTML/JSX/TXT sem estrutura clara ou com naming caótico (_5-__, snake_case misturado, prefixos numéricos). Skill otimizada para usuários low-code — confirmações obrigatórias antes de ações destrutivas, explicações inline, economia de tokens via progressive disclosure, hands-off workflow quando possível.
compatibility:
  tools:
    - bash_tool
    - create_file
    - view
    - str_replace
    - ask_user_input_v0
    - present_files
    - web_search (para validar práticas recentes Anthropic)
  integrations:
    - product-self-knowledge
    - x-ray-self-knowledge
    - x-ray-orchestrator
    - hyperautomation-diagnostico
    - internal-comms
    - doc-coauthoring
---

# Project Packager

**Transforma caos em repo production-ready com um comando.**

Sistema de packaging inteligente que:
- Escaneia /mnt/project/ ou diretório fornecido
- Detecta tipos de arquivo e classifica automaticamente
- Renomeia seguindo kebab-case + Git best practices
- Gera estrutura hierárquica padrão-ouro
- Cria README.md, .gitignore, docs customizados
- Exporta metadata estruturado em YAML para downstream
- Aplica QA gates com confirmação obrigatória
- Entrega ZIP pronto para `git push`

---

## QUANDO USAR ESTA SKILL

### Gatilhos Explícitos
```
"empacota esse projeto"
"estrutura repo para GitHub"
"normaliza esses arquivos"
"package project"
"gera ZIP estruturado"
"prepara para git push"
"organiza meus arquivos para repo"
"transforma isso em repositório"
"repo-ify this mess"
```

### Gatilhos Contextuais
- Usuário menciona `/mnt/project/` + múltiplos arquivos
- Arquivos com naming caótico: `_5-__ASS-01-EX-EBOOK.html`, `ex-ofice.txt`
- Projetos espalhados em múltiplas contas claude.ai
- Conversão de assets avulsos para base de conhecimento estruturada
- Preparação para integração com skills downstream (X-Ray, Bússola, FORGE)

### NÃO Usar Para
- Projetos já estruturados com package.json/pyproject.toml
- Repos ativos com .git existente (use git tools diretamente)
- Single-file scripts que não precisam de repo
- Perguntas sobre Git/GitHub (use product-self-knowledge)

---

## WORKFLOW CANÔNICO

```
┌─────────────────────────────────────────┐
│ 0. PRE-FLIGHT CHECK                     │
├─────────────────────────────────────────┤
│ → web_search práticas recentes Anthropic│
│ → Valida integração com skills citadas │
│ → Carrega templates + referências      │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│ 1. DISCOVERY & CLASSIFICATION           │
├─────────────────────────────────────────┤
│ → Escaneia source (default: /mnt/project/)│
│ → Detecta: .html, .jsx, .txt, .md, etc │
│ → Classifica: template/design/reference│
│ → Extrai metadata inline dos arquivos  │
│ → Detecta duplicatas e versões         │
│ → Flags arquivos malformados           │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│ 2. INTERACTIVE INTAKE (ask_user_input_v0)│
├─────────────────────────────────────────┤
│ Q1: Nome do repo? [auto: kebab-case]   │
│ Q2: Tipo de projeto?                   │
│   • X-Ray asset                         │
│   • Bússola PME                         │
│   • FORGE template                      │
│   • Generic workflow                    │
│   • Outro (especificar)                 │
│ Q3: Versão inicial? [auto: 1.0.0]      │
│ Q4: Workflow mode?                      │
│   • Hands-off (confirma só no final)   │
│   • Interactive (confirma cada etapa)  │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│ 3. NORMALIZATION ENGINE                 │
├─────────────────────────────────────────┤
│ → Renomeia: snake_case → kebab-case    │
│ → Remove: prefixos numéricos, __        │
│ → Converte: TXT → HTML se detectado    │
│ → Extrai: tags/keywords via NLP básico │
│ → Gera: structured_metadata.yaml       │
│ → Aplica: naming conventions Git       │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│ 4. REPO STRUCTURE BUILDER               │
├─────────────────────────────────────────┤
│ → Cria hierarquia tipo-específica      │
│ → Routing: template/design/reference   │
│ → Gera: README.md customizado          │
│ → Gera: .gitignore context-aware       │
│ → Gera: QUICKSTART.md                  │
│ → Gera: docs/context/project-context.md│
│ → Gera: docs/structured-metadata.yaml  │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│ 5. QA GATE (MANDATORY CONFIRMATION)     │
├─────────────────────────────────────────┤
│ 📊 Preview estrutura tree ASCII        │
│ 📋 Lista renomeações aplicadas         │
│ ⚠️  Flags problemas detectados          │
│ 💡 Sugestões de melhoria                │
│ ✅ "Confirma e gera ZIP?" [SIM/REVISAR] │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│ 6. PACKAGING + DELIVERY                 │
├─────────────────────────────────────────┤
│ → Gera ZIP otimizado (sem .git)        │
│ → Cria commit-message.txt sugerido     │
│ → Gera git-workflow.md hands-off       │
│ → Entrega via present_files            │
│ → Mostra próximos passos               │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│ 7. POST-DELIVERY BRIEFING               │
├─────────────────────────────────────────┤
│ → Copy-paste commands para unzip + push│
│ → Modelo sugerido: Sonnet/Opus/Haiku   │
│ → Economia de tokens: estimativa       │
│ → Workflow recomendado: Claude Code    │
│ → Integração com skills citadas        │
└─────────────────────────────────────────┘
```

---

## PROGRESSIVE DISCLOSURE — Token Economy

### Nível 1: Metadata (sempre carregado)
- Name + description (este frontmatter)
- ~200 palavras

### Nível 2: SKILL.md body (quando skill ativa)
- Workflow canônico
- Rules of conduct
- Este documento
- ~1500 palavras

### Nível 3: References (on-demand via view)
- `references/naming-conventions.md` — Regras de renomeação
- `references/gitignore-templates.md` — Templates por tipo de projeto
- `references/readme-templates.md` — Estruturas de README
- `references/metadata-schema.yaml` — Schema YAML canônico
- ~3000 palavras total

### Nível 4: Scripts (executam sem carregar)
- `scripts/normalize_naming.py` — Renomeação batch
- `scripts/detect_duplicates.py` — Detecção de duplicatas
- `scripts/extract_metadata.py` — Extração de tags/keywords
- `scripts/validate_structure.sh` — Validação pré-ZIP
- ~1000 linhas código total

**Total carregado por default:** ~1700 palavras (Nível 1 + 2)  
**Token savings vs inline:** ~80% (scripts executam, não carregam)

---

## RULES OF CONDUCT

### R01: CONFIRMAÇÃO OBRIGATÓRIA (Low-Code Protection)
```python
# Antes de QUALQUER ação destrutiva
if action in ["rename", "delete", "convert_format"]:
    confirm = ask_user_input_v0({
        "questions": [{
            "question": f"Aplicar {action} em {file}?",
            "type": "single_select",
            "options": ["✅ Sim", "✏️ Revisar", "❌ Pular"]
        }]
    })
    if confirm != "✅ Sim":
        handle_revision_or_skip()
```

### R02: EXPLICAÇÕES INLINE SEMPRE
Cada decisão técnica vem com explicação em português claro:
```markdown
**Por que kebab-case?** → Padrão Git/npm/Python. Evita problemas em Linux.
**Por que .gitignore?** → Previne commit de lixo (node_modules, .DS_Store).
```

### R03: ECONOMIA DE TOKENS VIA SCRIPTS
```python
# MAU: carregar arquivo inteiro para renomear
content = view(file)  # 10k tokens
renamed = rename_inline(content)

# BOM: script Python executável
bash("python scripts/normalize_naming.py {file}")  # 0 tokens carregados
```

### R04: WEB SEARCH PARA VALIDAÇÃO
Antes de aplicar convenções, valida práticas recentes:
```python
web_search("Anthropic Claude skills best practices 2026")
web_search("GitHub repository structure conventions 2026")
# Atualiza templates se houver mudanças
```

### R05: HANDS-OFF QUANDO POSSÍVEL
Se `workflow_mode == "hands-off"`:
- Aplica todas decisões automaticamente
- Confirma UMA VEZ no QA Gate final
- Entrega ZIP + briefing completo

Se `workflow_mode == "interactive"`:
- Confirma cada renomeação
- Mostra preview antes de cada etapa
- Permite rollback granular

### R06: METADATA ESTRUTURADO SEMPRE
Todo projeto gera `docs/structured-metadata.yaml`:
```yaml
project:
  name: xray-interactive-playbook
  type: x-ray-asset
  version: 1.0.0
  created: 2026-05-02
  
files:
  - source: _5-__ASS-01.html
    normalized: src/templates/ebook-interativo.html
    type: template
    tags: [x-ray, onboarding, consultant, client]
    size_kb: 99
    complexity: medium
```

Consumível por:
- Skills downstream (X-Ray, Bússola)
- DB warehouse (Notion, Airtable)
- Automações futuras

### R07: INTEGRAÇÃO COM SKILLS CITADAS
Se usuário tem estas skills ativas:
- `x-ray-self-knowledge` → Consulta routing para assets X-Ray
- `x-ray-orchestrator` → Valida estrutura contra canonical pipeline
- `hyperautomation-diagnostico` → Sugere automações pós-packaging
- `internal-comms` → Gera README em tom corporativo se aplicável
- `doc-coauthoring` → Aplica co-authoring workflow em docs/

### R08: DETECÇÃO DE DUPLICATAS INTELIGENTE
```python
if detect_duplicates([file1, file2]):
    ask_user_input_v0({
        "question": "Detectei 2 versões do mesmo arquivo. Qual manter?",
        "options": [
            "Mais recente (modified time)",
            "Maior tamanho (mais completo)",
            "Ambas como versões (v1/v2)"
        ]
    })
```

### R09: VALIDAÇÃO HTML/JSX AUTOMÁTICA
Antes de incluir no ZIP:
```bash
# Se .html presente
find src -name "*.html" -exec python scripts/validate_html.py {} \;

# Se .jsx presente  
find src -name "*.jsx" -exec node scripts/validate_jsx.js {} \;
```

Reporta erros mas não bloqueia (warning-only).

### R10: PROMPT COPY-PASTE NO FINAL
Entrega comandos executáveis direto:
```bash
# Para copiar e colar no terminal
unzip xray-interactive-playbook.zip
cd xray-interactive-playbook
git init
git add .
git commit -m "feat: initial commit v1.0.0"
git remote add origin https://github.com/USER/REPO.git
git push -u origin main
```

---

## MODELO SUGERIDO (Context-Aware)

### Decisão Automática
```python
if total_files < 10 and total_size_kb < 500:
    model = "claude-haiku-4"  # Rápido + barato
elif total_files < 50 and workflow_mode == "hands-off":
    model = "claude-sonnet-4"  # Balanceado
else:
    model = "claude-opus-4"  # Complexidade alta + interactive
```

### Justificativa ao Usuário
```
📊 Análise do projeto:
  • 6 arquivos, 460KB total
  • Workflow: hands-off
  • Complexidade: média

💡 Modelo recomendado: Claude Sonnet 4.5
  • Custo: ~$0.03 para processar
  • Tempo: ~15 segundos
  • Tokens estimados: 8k input + 2k output

Quer usar outro modelo? [Sonnet ✓ | Haiku | Opus]
```

---

## TOKEN ECONOMY — Estimativas

| Etapa | Tokens (com skill) | Tokens (sem skill) | Economia |
|-------|--------------------|--------------------|----------|
| Discovery | 500 | 2000 | 75% |
| Normalization | 800 (script) | 5000 (inline) | 84% |
| Structure Build | 1200 | 3000 | 60% |
| QA Gate | 600 | 600 | 0% |
| Packaging | 300 (script) | 2000 (inline) | 85% |
| **TOTAL** | **~3400** | **~12600** | **73%** |

**Saving real:** ~9k tokens por projeto = ~$0.02 por run (Sonnet pricing).

Em 100 projetos: **$2 saved** + tempo humano massivamente reduzido.

---

## INTEGRAÇÃO COM SKILLS

### Com `x-ray-self-knowledge`
```python
# Antes de classificar tipo de projeto
x_ray_knowledge = tool_search("x-ray-self-knowledge")
if x_ray_knowledge:
    routing = call_skill("x-ray-self-knowledge", 
                         query="qual skill X-Ray este asset pertence?")
    # Usa resposta para customizar estrutura
```

### Com `x-ray-orchestrator`
```python
# Se tipo == "x-ray-asset"
if has_skill("x-ray-orchestrator"):
    validate_canonical_pipeline(metadata)
    # Garante IDs canônicos S00-S20, GATE-G0-G12, etc
```

### Com `hyperautomation-diagnostico`
```python
# Pós-packaging
if has_skill("hyperautomation-diagnostico"):
    suggest_automation({
        "task": "Sync repo → Notion via GitHub Actions",
        "roi": "4h/semana economizadas",
        "effort": "30min setup"
    })
```

### Com `internal-comms`
```python
# Se README precisa de tom corporativo
if has_skill("internal-comms"):
    tone = "executive-grade"
else:
    tone = "developer-friendly"
```

### Com `doc-coauthoring`
```python
# Ao gerar docs/context/project-context.md
if has_skill("doc-coauthoring"):
    apply_coauthoring_workflow()
    # Iteração estruturada + validation gates
```

---

## WORKFLOW EXAMPLES — One-Take Hands-Off

### Exemplo 1: Asset X-Ray Simples
```
User: "empacota esse projeto como repo X-Ray"

Claude:
[web_search: Anthropic skills 2026]
[escaneia /mnt/project/ → 6 arquivos]
[ask_user_input_v0: tipo=X-Ray, mode=hands-off]
[normaliza tudo automaticamente]
[gera estrutura]
[QA gate: mostra preview]
User: "confirma"
[gera ZIP]
✓ xray-interactive-playbook.zip (136KB)

Próximos passos:
```bash
unzip xray-interactive-playbook.zip
cd xray-interactive-playbook
git init && git add . && git commit -m "feat: v1.0"
git remote add origin https://github.com/USER/REPO.git
git push -u origin main
```

Modelo usado: Sonnet 4.5
Tokens: 3.2k input + 1.8k output
Custo: $0.027
Tempo: 12 segundos
```

### Exemplo 2: Multi-Asset com Duplicatas
```
User: "normaliza esses 15 arquivos espalhados"

Claude:
[detecta duplicatas: 3 pares]
[ask_user_input_v0: resolve duplicatas]
User: [escolhe versões]
[normaliza 12 arquivos únicos]
[classifica: 5 templates, 4 designs, 3 references]
[gera estrutura multi-folder]
[QA gate]
User: "parece bom"
[ZIP + metadata.yaml]
✓ multi-asset-bundle.zip (2.1MB)
✓ Metadata exportado para downstream

Modelo usado: Opus 4.6 (complexidade alta)
Tokens: 8.5k input + 3.2k output
Custo: $0.14
```

### Exemplo 3: Conversão TXT → HTML
```
User: "prepara isso para repo, o ex-ofice.txt é HTML mal-nomeado"

Claude:
[detecta ex-ofice.txt → HTML content inside]
💡 Arquivo "ex-ofice.txt" parece HTML. Converter para .html?
User: "sim"
[converte → executive-office.html]
[valida HTML syntax]
[inclui em src/templates/]
[resto do workflow...]
```

---

## REFERÊNCIAS INTERNAS

Quando precisar de detalhes técnicos, carregue sob demanda:

```python
# Naming conventions completas
view("references/naming-conventions.md")

# Templates .gitignore por tipo
view("references/gitignore-templates.md")

# Estruturas README variadas
view("references/readme-templates.md")

# Schema YAML metadata
view("references/metadata-schema.yaml")

# Scripts executáveis
bash("python scripts/normalize_naming.py --help")
```

---

## TROUBLESHOOTING

### Problema: "Skill não ativou quando mencionei /mnt/project/"
**Solução:** Gatilho requer contexto adicional. Diga explicitamente "empacota" ou "estrutura repo".

### Problema: "Renomeação aplicou convenção errada"
**Solução:** Skill usa `references/naming-conventions.md`. Se divergir, atualize o reference file.

### Problema: "ZIP muito grande (>10MB)"
**Solução:** Skill flags arquivos >5MB. Exclua assets binários grandes antes de zipar.

### Problema: "Metadata YAML não gera"
**Solução:** Requer pelo menos 1 arquivo classificável. Se todos são binários, metadata fica vazio.

---

## MANUTENÇÃO DA SKILL

### Atualização de Práticas
A cada 3 meses ou quando Anthropic lança guidelines novos:
```bash
# Re-run web search
web_search("Anthropic Claude skills best practices {current_year}")

# Atualiza references/
update_reference_files(new_practices)

# Incrementa versão
bump_version("1.1.0")
```

### Feedback Loop
Após cada uso:
```python
# Log decisões tomadas
log_to_file("examples/case-{id}.yaml", {
    "input": files_scanned,
    "decisions": normalizations_applied,
    "output": zip_structure,
    "user_feedback": feedback_score
})

# A cada 10 usos, analisa padrões
if usage_count % 10 == 0:
    analyze_common_patterns()
    suggest_skill_improvements()
```

---

## LIMITAÇÕES CONHECIDAS

1. **Não cria .git automaticamente** — Usuário faz `git init` manualmente
2. **Não faz push automático** — Requer credenciais do usuário
3. **Validação HTML básica** — Usa regex, não parser completo
4. **NLP de tags simples** — Keyword extraction, não semântica profunda
5. **Duplicatas por nome/tamanho** — Não compara conteúdo byte-a-byte

---

## CHANGELOG

### v1.0.0 (2026-05-02)
- Initial release
- Workflow canônico 7 etapas
- Integração com 5 skills (X-Ray, hyperautomation, etc)
- Token economy 73%
- Hands-off + interactive modes
- Metadata YAML estruturado

---

## PRÓXIMOS PASSOS APÓS USAR SKILL

1. ✅ Unzip o pacote entregue
2. ✅ Review estrutura gerada
3. ✅ `git init && git add . && git commit`
4. ✅ Push para GitHub
5. 🎯 Conectar Claude Code ao repo
6. 🎯 Testar workflow: `view` → edit → commit via Claude Code
7. 🎯 Integrar com skills downstream (se aplicável)

---

**Skill mantida por:** Leonardo Batista  
**Versão:** 1.0.0  
**Última atualização:** 2026-05-02  
**Licença:** Proprietária (X-Ray OS)
