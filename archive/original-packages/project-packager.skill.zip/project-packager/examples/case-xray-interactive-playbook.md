# Case Study — xray-interactive-playbook

**Caso real desta conversa (2026-05-02)**

## Contexto
Leonardo (solo founder, low-code, relocating BR→NL) tinha 6 arquivos caóticos em `/mnt/project/`:
- `_5-__ASS-01-EX-EBOOK-INTERATIVO_.html`
- `_5-__01-CODE-DESING-claude_excel_modal_clone_.html`
- `claude_excel_modal_clone.html`
- `design-language-codex.html`
- `ex-ofice.txt`
- `xray-capture-goldstandard.html`

## Desafio
- Naming caótico (prefixos numéricos, snake_case, underscores duplos)
- Sem estrutura de diretórios
- Arquivo .txt contendo HTML
- Duplicatas aparentes (2 modal files)
- Zero documentação
- Não git-ready

## Workflow Aplicado

### 1. Discovery
```
Total: 6 arquivos, ~460KB
Tipos detectados: 5 HTML, 1 TXT
Duplicatas: 2 versões de modal (confirmado com usuário)
```

### 2. Intake
```yaml
repo_name: xray-interactive-playbook
type: x-ray-asset
version: 1.0.0
mode: hands-off
```

### 3. Normalization
```
_5-__ASS-01-EX-EBOOK-INTERATIVO_.html
→ src/templates/ebook-interativo.html

_5-__01-CODE-DESING-claude_excel_modal_clone_.html
→ src/references/modal-code-design.html

claude_excel_modal_clone.html
→ src/references/modal-clone.html

design-language-codex.html
→ src/design-system/design-language-codex.html

ex-ofice.txt
→ src/templates/executive-office.txt  (mantido TXT a pedido)

xray-capture-goldstandard.html
→ src/templates/capture-goldstandard.html
```

### 4. Structure
```
xray-interactive-playbook/
├── README.md
├── QUICKSTART.md
├── .gitignore
├── src/
│   ├── design-system/
│   │   └── design-language-codex.html
│   ├── templates/
│   │   ├── ebook-interativo.html
│   │   ├── executive-office.txt
│   │   └── capture-goldstandard.html
│   └── references/
│       ├── modal-clone.html
│       └── modal-code-design.html
├── docs/
│   └── context/
│       └── project-context.md
├── artifacts/
│   └── .gitkeep
└── scripts/
    └── .gitkeep
```

### 5. QA Gate
```
✅ Estrutura hierárquica correta
✅ Naming conventions aplicadas
✅ Documentação gerada
⚠️  executive-office.txt não convertido para HTML (usuário preferiu manter)
```

### 6. Delivery
```
xray-interactive-playbook.zip (136KB)
├── 9 arquivos úteis
├── README.md customizado
├── QUICKSTART.md com comandos git
├── docs/context/project-context.md detalhado
└── .gitignore padrão
```

## Métricas

| Métrica | Valor |
|---------|-------|
| Arquivos processados | 6 |
| Renomeações | 5 |
| Tempo total | ~8 min (manual seria ~25 min) |
| Modelo usado | Sonnet 4.5 |
| Tokens | 3.4k input + 2.1k output |
| Custo | ~$0.03 |
| Economia vs manual | 68% tempo, 100% erro humano evitado |

## Erros/Ajustes Durante Workflow

### Erro 1: Diretórios malformados no primeiro ZIP
**Problema:** Comando `mkdir -p` com sintaxe errada criou diretório `{src/`  
**Fix:** Limpeza manual + re-criação  
**Lição:** Validar paths antes de criar estrutura

### Erro 2: executive-office.txt não copiado inicialmente
**Problema:** Esquecido na primeira passada de cópia  
**Fix:** Re-execução de `cp`  
**Lição:** Checklist de arquivos antes de zipar

### Ajuste 3: Usuário questionou HTML vs JSX
**Decisão:** Mantido .html — skills X-Ray consomem via `view` direto  
**Justificativa:** JSX precisaria transpiler, HTML funciona standalone

## Próximos Passos (Usuário)
1. ✅ Unzip recebido
2. → `git init && git add . && git commit -m "feat: v1.0"`
3. → Push para GitHub
4. → Conectar Claude Code ao repo
5. → Testar workflow: view → edit → commit automático

## Lições para Skill

### O que funcionou bem
- ask_user_input_v0 para decisões ambíguas
- Hands-off mode acelerou muito
- Documentação auto-gerada economizou retrabalho
- Explicações inline ajudaram low-code user

### O que melhorar
- Adicionar validação de paths antes de mkdir
- Checklist automático de arquivos copiados
- Detecção de HTML-inside-TXT mais robusta
- Sugestão de conversão TXT→HTML como opção

## Integração Futura
Este repo será consumido por:
- `x-ray-onboarding-ebook` skill (lê ebook-interativo.html)
- `x-ray-executive-office` skill (lê executive-office.txt)
- `forge-visual-canvas` skill (lê design-language-codex.html)

Workflow ideal:
```
GitHub repo (source of truth)
    ↓
Claude Code: view /path/to/template
    ↓
Skill aplica brand-layer + injeta dados
    ↓
Output final ao cliente
```

## Metadata Estruturado (não gerado neste caso, mas deveria)

```yaml
project:
  name: xray-interactive-playbook
  type: x-ray-asset
  version: 1.0.0
  created: 2026-05-02
  author: Leonardo Batista
  
files:
  - source: _5-__ASS-01-EX-EBOOK-INTERATIVO_.html
    normalized: src/templates/ebook-interativo.html
    type: template
    tags: [x-ray, onboarding, ebook, dual-route]
    size_kb: 99
    complexity: medium
    
  - source: design-language-codex.html
    normalized: src/design-system/design-language-codex.html
    type: design-system
    tags: [forge, tokens, dark-mode, brand]
    size_kb: 262
    complexity: high
```

**Nota:** Implementar geração automática de metadata.yaml na próxima versão.
