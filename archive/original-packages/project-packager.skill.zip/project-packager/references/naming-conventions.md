# Naming Conventions — Project Packager

## Regras Canônicas

### R1: Kebab-Case Sempre
❌ snake_case_file.html → ✅ kebab-case-file.html

### R2: Sem Prefixos Numéricos  
❌ _5-__ASS-01-EX.html → ✅ ebook-interativo.html

### R3: Lowercase Sempre
❌ MyFile.html → ✅ myfile.html

## Mapeamento Automático
- `_N-__*` → Remove prefixo
- `snake_case` → `kebab-case`
- `.txt` (HTML) → `.html`
- Espaços → hífens
