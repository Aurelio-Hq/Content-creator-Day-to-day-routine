# Trigger Table — Project Packager

## Gatilhos Simples

| Frase do Usuário | Ativa? | Workflow | Exemplo |
|------------------|--------|----------|---------|
| "empacota esse projeto" | ✅ | Full workflow | User tem arquivos em /mnt/project/, quer repo |
| "estrutura repo para GitHub" | ✅ | Full workflow | Preparar push inicial |
| "normaliza esses arquivos" | ✅ | Normalization-only | Só renomear, não criar estrutura completa |
| "package project" | ✅ | Full workflow | EN variant |
| "gera ZIP estruturado" | ✅ | Full workflow | Output direto |
| "prepara para git push" | ✅ | Full workflow | Git-ready output |
| "organiza meus arquivos" | ⚠️ | Needs context | Só ativa se mencionar "repo" ou "GitHub" |
| "transforma em repositório" | ✅ | Full workflow | Clear intent |
| "repo-ify this" | ✅ | Full workflow | Slang variant |
| "cria repo desses files" | ✅ | Full workflow | PT-BR casual |
| "quero subir isso no GitHub" | ✅ | Full workflow | Intent-based trigger |

## Gatilhos Contextuais

| Contexto | Ativa? | Condição | Workflow |
|----------|--------|----------|----------|
| Arquivos em /mnt/project/ | ⚠️ | + frase "estrutura" ou "repo" | Full workflow |
| Naming caótico detectado | ⚠️ | + menção de "normaliza" | Normalization + structure |
| Múltiplas contas mencionadas | ✅ | User diz "espalhados" | Discovery multi-source |
| Asset X-Ray mencionado | ✅ | Auto-detecta tipo | X-Ray-specific structure |
| "projeto tem 10+ arquivos" | ⚠️ | + trigger explícito | Hands-off mode sugerido |

## Workflows Detalhados

### 1. Full Workflow (One-Take Hands-Off)
**Trigger:** "empacota esse projeto como X-Ray"
```
User input → Ask tipo/versão → Scan files → Normalize → Build structure → QA gate → ZIP → Deliver
Tempo: ~15 seg | Tokens: 3.4k | Modelo: Sonnet
```

### 2. Normalization-Only
**Trigger:** "normaliza só os nomes, não cria estrutura"
```
Scan → Detect naming issues → Ask confirmations → Rename → Report changes
Tempo: ~5 seg | Tokens: 800 | Modelo: Haiku
```

### 3. Interactive Mode
**Trigger:** "estrutura repo mas confirma cada passo"
```
Scan → Ask tipo → Normalize (confirm each) → Structure (preview) → QA → ZIP
Tempo: ~3 min (depende de user) | Tokens: 4.5k | Modelo: Sonnet
```

### 4. Multi-Asset Bundle
**Trigger:** "empacota esses 15 arquivos de 3 projetos diferentes"
```
Scan all → Detect duplicates → Classify by project → Separate structures → Multi-ZIP
Tempo: ~45 seg | Tokens: 9k | Modelo: Opus
```

### 5. Convert + Package
**Trigger:** "esse TXT é HTML, converte e empacota"
```
Detect HTML in TXT → Convert ext → Validate → Continue full workflow
Tempo: ~20 seg | Tokens: 4k | Modelo: Sonnet
```

## Anti-Triggers (Quando NÃO Ativar)

| Frase | Por quê NÃO ativar |
|-------|-------------------|
| "como funciona Git?" | Pergunta educacional → use product-self-knowledge |
| "lê esse PDF" | Task específica → use pdf skill direto |
| "ajuda com meu código Python" | Coding task → não é packaging |
| "preciso criar um repo novo" | Ambíguo — ask se já tem arquivos para estruturar |
| "faz deploy disso" | Deploy ≠ packaging → use deployment skill |

## Integração com Outras Skills

| Skill Ativa | Integração | Exemplo |
|-------------|-----------|---------|
| x-ray-self-knowledge | Consulta routing | "Qual skill X-Ray esse asset usa?" |
| x-ray-orchestrator | Valida pipeline | Garante IDs canônicos S00-S20 |
| hyperautomation-diagnostico | Sugere automação | "Sync repo → Notion via Actions" |
| internal-comms | Ajusta tom README | Tom corporativo vs dev-friendly |
| doc-coauthoring | Workflow estruturado | Docs gerados com validation gates |

## Modelo Sugerido por Caso

| Caso | Files | Size | Complexity | Modelo | Custo |
|------|-------|------|------------|--------|-------|
| Simples (< 10 files, < 500KB) | 6 | 460KB | Baixa | Haiku 4 | $0.01 |
| Médio (10-50 files, < 5MB) | 25 | 2.3MB | Média | Sonnet 4.5 | $0.08 |
| Complexo (50+ files, > 5MB) | 120 | 18MB | Alta | Opus 4.6 | $0.45 |
| Multi-asset | 15 (3 proj) | 3MB | Média-Alta | Opus 4.6 | $0.25 |

## Economia de Tokens — Comparação

| Etapa | Sem Skill | Com Skill | Economia |
|-------|-----------|-----------|----------|
| Discovery | 2000 | 500 | 75% |
| Normalization | 5000 (inline) | 800 (script) | 84% |
| Structure | 3000 | 1200 | 60% |
| Packaging | 2000 (inline) | 300 (script) | 85% |
| **Total** | **12000** | **3400** | **73%** |

## Exemplos de Conversas Reais

### Exemplo 1: Usuário Low-Code
```
User: "tenho esses arquivos bagunçados, preciso subir no GitHub mas não sei estruturar"
Skill: ✅ ATIVA
Workflow: Full + Interactive (confirma cada renomeação)
Output: ZIP + tutorial passo-a-passo
```

### Exemplo 2: Usuário Senior Dev
```
User: "package this, hands-off mode, X-Ray asset"
Skill: ✅ ATIVA
Workflow: Full + Hands-off (confirma só QA final)
Output: ZIP + commit message sugerido
```

### Exemplo 3: Usuário Confuso
```
User: "não sei o que fazer com esses arquivos"
Skill: ⚠️ ASKS CLARIFICATION
Response: "Quer estruturar como repositório Git? Ou apenas organizar localmente?"
User: "repo Git sim"
Skill: ✅ ATIVA (após clarificação)
```

### Exemplo 4: Conversão TXT→HTML
```
User: "esse ex-ofice.txt parece HTML, arruma isso"
Skill: ✅ ATIVA
Workflow: Detect HTML → Suggest conversion → User confirms → Convert → Package
```

## Próximos Passos Típicos Após Skill

1. **Unzip + Review**
```bash
unzip project-name.zip
cd project-name
tree -L 2  # Verificar estrutura
```

2. **Git Init + Commit**
```bash
git init
git add .
git commit -m "feat: initial commit v1.0.0"
```

3. **Push para GitHub**
```bash
git remote add origin https://github.com/USER/REPO.git
git push -u origin main
```

4. **Conectar Claude Code**
```bash
cd /path/to/repo
code .  # Abre VS Code com Claude Code extension
# Claude Code detecta repo automaticamente
```

5. **Testar Workflow**
```
# No Claude Code
"view src/templates/file.html"
[edita via prompt]
"commit essas mudanças"
```

## Feedback Loop

Após cada uso, skill loga:
```yaml
usage_log:
  timestamp: 2026-05-02T14:32:00Z
  user_id: leonardo-batista
  files_scanned: 6
  normalizations: 5
  structure_type: x-ray-asset
  mode: hands-off
  model_used: sonnet-4.5
  tokens: {input: 3400, output: 2100}
  cost: 0.027
  user_satisfaction: 5/5
  issues_encountered: []
  suggestions: ["Add metadata.yaml auto-generation"]
```

A cada 10 usos, analisa padrões e sugere melhorias à skill.
