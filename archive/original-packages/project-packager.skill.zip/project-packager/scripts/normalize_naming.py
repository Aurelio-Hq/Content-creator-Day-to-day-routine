#!/usr/bin/env python3
"""
Normalize file naming to kebab-case Git conventions.
Usage: python normalize_naming.py <file_path>
"""
import sys
import re
from pathlib import Path

def normalize_filename(name: str) -> str:
    """Convert filename to kebab-case Git conventions."""
    base, ext = name.rsplit('.', 1) if '.' in name else (name, '')
    
    # Remove numeric prefixes like _5-__, 01-, etc
    base = re.sub(r'^[\d_-]+', '', base)
    
    # Replace underscores/spaces with hyphens
    base = base.replace('_', '-').replace(' ', '-')
    
    # Lowercase
    base = base.lower()
    
    # Remove multiple consecutive hyphens
    base = re.sub(r'-+', '-', base)
    
    # Remove leading/trailing hyphens
    base = base.strip('-')
    
    return f"{base}.{ext.lower()}" if ext else base

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python normalize_naming.py <file_path>")
        sys.exit(1)
    
    old_path = Path(sys.argv[1])
    new_name = normalize_filename(old_path.name)
    new_path = old_path.parent / new_name
    
    print(f"{old_path.name} → {new_name}")
    
    if old_path != new_path:
        old_path.rename(new_path)
        print(f"✓ Renamed")
    else:
        print(f"✓ Already normalized")
