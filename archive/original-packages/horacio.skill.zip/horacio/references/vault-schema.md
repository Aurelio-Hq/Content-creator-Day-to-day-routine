# Vault Schema + Storage Targets — Horácio v2

## Master Vault Entry Schema

```
| ID | Chat Name | Type | Frame | Question | Output | Data/Metric | Owner | Priority | Status | Tags |
|---|---|---|---|---|---|---|---|---|---|---|
| V-YYYYMMDD-### | [name] | [type] | [frame] | [decision question] | [output produced] | [key metric] | Leonardo | Alta/Média/Baixa | Draft | #tag |
```

**Type options:** `Idea | Thesis | Plan | Analysis | Decision | Task`
**Frame options:** `strategy | market | product | finance | growth | ops | risk | validation | execution`
**Status options:** `Draft | Active | Validating | Decision | Archived`

---

## Storage Target Map

| Output Type | Primary Target | Format | Reason |
|---|---|---|---|
| Master thesis / business thesis | `1_Master_Index.md` | Markdown | Central retrieval anchor |
| Workflows / operating procedures | `2_Horacio_Workflows.md` | Markdown | Reusable operating process |
| Structured rows / database | `3_CMD_Operations.xlsx` | Table/XLS | Filterable, sortable database |
| Decisions / audit trail | `4_Decision_Trace_Log.md` | Markdown + table | Decision traceability |
| Prompts / skills / commands | `/skills/` or Project Instructions | Markdown | Reuse across sessions |
| Sources / citations | `REFERENCIAS_ABNT` | Table | Citation registry |
| Gaps / missing info | `GAPS` | Table | Missing info tracker |
| Signal clusters | `5_Signals_Log.md` | Table | Market intelligence |
| Agent specs | `HORACIO_AGENT_SPEC.md` | Markdown | Agent design reference |

---

## Writeback Decision Rule

```
IF output is reusable across sessions
  → assign to named storage target (above)
ELSE IF output is one-off synthesis
  → tag as Archived after use
ELSE IF output is a decision
  → 4_Decision_Trace_Log.md + vault entry
ELSE IF output is missing data
  → GAPS table + G-### ID
```

**Prefer: Markdown / XLS → Supabase**
Use Supabase/database only when automation, multi-user access, or API integration is explicitly required.

---

## Delivery Artifacts Menu

| Artifact | Use Case | Format |
|---|---|---|
| `HORACIO_AGENT_SPEC.md` | Design an agent | Markdown spec |
| `SKILL.md` | Create Claude Skill | YAML + Markdown |
| `CMD_RUNBOOK.md` | Document operating workflow | Markdown |
| `RAG_KNOWLEDGE_PACK.md` | Extracted knowledge | Typed table |
| `DECISION_TRACE.md` | Decision audit trail | Markdown + table |
| `VAULT_IMPORT.csv` | Bulk database import | CSV |
| `SUPABASE_SCHEMA.sql` | Backend schema (late stage) | SQL |
| `PROMPT_CACHE.md` | Reusable project instruction | Markdown |
| `SIGNAL_REPORT.md` | Market intelligence output | Typed table |
| `GAPS_REGISTER.md` | Open questions tracker | Table |

---

## Version Naming

Chat / output ID format:
```
V-YYYYMMDD-### — [Short Name] — #[main] #[secondary] — [Status]
```

Example:
```
V-20260508-001 — Horácio Market Validation — #strategy #validation — Active
```

Increment ### sequentially within the same day.

---

## Master Index Template (`1_Master_Index.md`)

```markdown
# Horácio Master Index

## Business Thesis
[Core thesis statement — 1 sentence]

## Active Projects
| ID | Name | Status | Frame | Owner |

## Key Decisions
| D-### | Decision | Date | Status |

## Open Gaps
| G-### | Description | Blocking | Status |

## Signal Archive
| SIG-### | Signal | Date | Reliability |

## Reference Registry
| SRC-### | Source | Type | Used in |
```
