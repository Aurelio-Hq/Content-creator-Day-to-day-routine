# Epistemic Schema Reference — Horácio v2

## Prefix Registry

| Prefix | Tipo | Definição | Quando usar |
|---|---|---|---|
| F-### | FATO | Fato verificável ou extraído de fonte | Dado confirmado, métrica real, afirmação de fonte primária |
| H-### | HIPÓTESE | Suposição que precisa de validação | Crença sem evidência suficiente, assume que X é verdade |
| I-### | INFERÊNCIA | Conclusão razoada a partir de F+H | "Dado F-001 e H-002, concluo que..." |
| D-### | DECISÃO | Escolha explícita ou recomendação | Direção tomada ou proposta com racional |
| R-### | RISCO | Incerteza, ameaça, dependência, modo de falha | Algo que pode dar errado ou bloquear |
| T-### | TAREFA | Próxima ação concreta | Ação com output esperado e dono |
| M-### | MÉTRICA | KPI ou métrica de validação | Indicador para confirmar hipótese ou medir resultado |
| G-### | GAP | Informação faltando | Dado necessário que não está disponível |
| SIG-### | SIGNAL | Sinal de mercado, cliente, dado ou comportamento | Evidência fraca ou forte de tendência externa |
| SRC-### | SOURCE | Item do registro de fontes | Origem de qualquer dado citado |

---

## Normalized Row Schema (Padrão)

```
| ID | Tipo | Statement | Source | Confidence | Implication | Next Action | Storage Target |
|---|---|---|---|---|---|---|---|
| F-001 | FATO | [statement] | SRC-001 | Alta | [implication] | [action] | [target] |
| H-001 | HIPÓTESE | [assumption] | Inferência | Média | [implication] | Validar: [method] | VAULT |
| G-001 | GAP | [missing info] | N/A | N/A | Bloqueia D-### | Coletar: [method] | GAPS |
```

**Confidence levels:** `Alta | Média | Baixa | N/A`

---

## GAPS Table Schema

Usar quando informação crítica está faltando. **NUNCA inventar dados faltantes.**

```
| GAP ID | Descrição | Impacto | Como Coletar | Owner | Deadline | Status |
|---|---|---|---|---|---|---|
| G-001 | [what's missing] | Bloqueia [D-### or decision] | [method] | Leonardo | [date] | Open |
```

---

## Decision Table Schema

```
| ID | Decision | Rationale | Evidence | Go Condition | No-Go Condition | Owner | Status |
|---|---|---|---|---|---|---|---|
| D-001 | [choice] | [why] | F-###, I-### | [condition to proceed] | [condition to stop] | Leonardo | Draft |
```

**Status options:** `Draft | Active | Validated | Reversed | Archived`

---

## Risk Table Schema

```
| ID | Risco | Tipo | Probabilidade | Impacto | Mitigação | Trigger | Owner | Status |
|---|---|---|---|---|---|---|---|---|
| R-001 | [risk] | Técnico/Mercado/Execução/Financeiro | Alta/Média/Baixa | Alta/Média/Baixa | [action] | [event] | Leonardo | Open |
```

---

## Source Registry Schema

```
| SRC ID | Nome | Tipo | URL/Referência | Data Acesso | Confiabilidade | Usado em |
|---|---|---|---|---|---|---|
| SRC-001 | [source name] | Primária/Oficial/Relatório/Jornalismo/Inferência | [url] | [date] | Alta/Média/Baixa | F-001, SIG-002 |
```

**Source ranking (alta → baixa):**
1. Fonte primária (pesquisa direta, entrevista)
2. Oficial (governo, filings, dados regulatórios)
3. Relatório empresarial (Gartner, McKinsey, setor)
4. Jornalismo reputável
5. Notas do usuário
6. Inferência

---

## Epistemic Separation Rules

1. **Nunca colocar F e H na mesma afirmação** — separar sempre
2. **Nunca promover H para F** sem evidência explícita
3. **Toda I deve citar pelo menos um F** (basis for reasoning)
4. **Toda D deve citar pelo menos uma I ou F** (basis for decision)
5. **GAP bloqueia D** — não tomar decisão sobre dado faltante
6. **T deve ter output concreto e owner** — nunca tarefa genérica

---

## Example Block (Micro)

```markdown
## RAG Knowledge Pack

| ID | Tipo | Statement | Source | Confidence | Implication | Next Action | Storage Target |
|---|---|---|---|---|---|---|---|
| F-001 | FATO | PMEs brasileiras gastam 8h/semana em tarefas repetitivas de dados | SRC-001 | Alta | Alta dor comprável | Validar em entrevistas | 3_CMD_Operations.xlsx |
| H-001 | HIPÓTESE | Cliente pagaria por implementação, não curso | Inferência | Média | Oferta deve ser serviço premium | Rodar 3 entrevistas JTBD | VAULT |
| I-001 | INFERÊNCIA | Há janela de mercado em automação operacional sem código | F-001, H-001 | Média | Mover para piloto manual | Montar protótipo em 2 semanas | 2_Horacio_Workflows.md |
| G-001 | GAP | Não temos dado de willingness-to-pay confirmado | N/A | N/A | Bloqueia D-001 | Survey 10 prospects | GAPS |
```
