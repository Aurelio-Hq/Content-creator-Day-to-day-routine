# Framework Reference — Horácio v2

## Selection Rule

Use the **minimum useful framework**. Over-framing is a quality failure.

| User Need | Preferred Frame | When to Skip |
|---|---|---|
| Business overview | Resumo Executivo | Never skip for first output |
| Root cause | First Principles / Issue Tree | Skip if root is already known |
| Market context | PESTEL / PASTEL | Skip if market is well-understood |
| Problem definition | Issue/Problem Tree | Skip if problem is clear |
| Offer design | 5P (Product, Price, Place, Promo, People) | Skip if offer is fixed |
| Execution plan | 5W2H | Skip if task is simple T-### |
| Customer value | JTBD (Jobs-to-be-Done) | Skip if customer need is known |
| Data validation | Data/Metrics first principles | Never skip for data tasks |
| Unknowns | Risks / Unknowns table | Never skip if G-### present |
| Immediate work | Next Actions | Never skip |

---

## Resumo Executivo (Default First Output)

5–10 lines max. Structure:
1. Context (1 line)
2. Core finding or decision (1–2 lines)
3. Key evidence (1–2 lines, typed as F/I)
4. Risk or gap (1 line)
5. Recommended next action (1 line)

---

## 5W2H (Execution Tasks)

| Element | Question | Example |
|---|---|---|
| What | O que fazer? | Mapear 3 workflows quebrados |
| Why | Por que? | Validar dor comprável antes de propor solução |
| Who | Quem? | Leonardo |
| Where | Onde? | Entrevistas com clientes-alvo |
| When | Quando? | Até D+5 |
| How | Como? | Roteiro de entrevista JTBD, 30min por cliente |
| How much | Quanto custa? | 0 CAPEX, 3h de tempo |

---

## JTBD (Jobs-to-be-Done)

For customer-facing research or offer design:

```
Job: [verb] + [object] + [context]
  e.g., "Reduzir tempo gasto em tarefas repetitivas de relatório"

Functional job: what they literally need to do
Emotional job: how they want to feel
Social job: how they want to be perceived

Pain magnitude (1–5): intensity of current frustration
Frequency: daily | weekly | monthly | quarterly
Willingness to pay proxy: "Would pay to make this go away? Y/N"
```

---

## Issue Tree (Root Cause)

```
Problem
├── Hypothesis A
│   ├── Sub-cause A1 (F-### or H-###)
│   └── Sub-cause A2
└── Hypothesis B
    ├── Sub-cause B1
    └── Sub-cause B2

Evidence status per branch:
  ✅ Confirmed (F-###)
  ⏳ Validating (H-###)
  ❌ Ruled out
  ◯ Unknown (G-###)
```

---

## PESTEL (Market Context)

Use for broad market scans. Only include factors with evidence:

| Factor | Finding | Type | Source | Implication |
|---|---|---|---|---|
| Political | | F/H/SIG | SRC-### | |
| Economic | | F/H/SIG | SRC-### | |
| Social | | F/H/SIG | SRC-### | |
| Technological | | F/H/SIG | SRC-### | |
| Environmental | | F/H/SIG | SRC-### | |
| Legal | | F/H/SIG | SRC-### | |

---

## MECE Compression Groups (Default)

When compressing signal clusters:

```
market_demand       → Is there real demand? Volume? Trend?
buyer_pain          → What hurts enough to pay to fix?
workflow_gap        → What process is broken or missing?
decision_gap        → What can't buyers decide without?
pricing             → What would they pay? How?
competition         → Who else is solving this? How saturated?
execution_constraint → What blocks us from delivering?
moat               → What makes this defensible?
risk               → What could kill this?
next_action         → What do we do now?
```

One entry per group maximum (if using compression). If more than 3 signals per group → summarize into 1 row with `count: N signals merged`.
