# LIVE COMMANDS INDEX

|ID|Nome|Finalidade|Outputs|
|---|---|---|---|
|CMD_PROJECT_HANDOFF_REASONING_OPEN_V2|Project Handoff V2|Operar a conversa como Single Conversation Document Factory + Decision Gates.|diagnóstico, mapa de fases, documentos, gate, próximas 3 tarefas|
|CMD_PROJECT_HANDOFF_REASONING_OPEN_V1|Project Handoff V1|Escanear conversa exportada e gerar cinco documentos operacionais iniciais.|PROJECT_USER_MESSAGE.md, PROJECT_MANIFESTO.md, MASTER_ACTION_UNIT.md, PHASED_WORKFLOW_MAP.md, NEXT_3_TASKS_PROTOCOL.md|
|CMD_DISCOVERY_EXIT_VAULT_BUILDER_V1|Discovery Exit Vault Builder|Transformar corpus disperso em base de decisão para sair de Discovery.|índices CSV, score de portfólio, top 3 MVP, top 5 conteúdos, backlog 7 dias|
|CMD_MARKET_MONETIZATION_TRIANGULATION_BRASIL_2026_V1|Market Monetization Triangulation|Avaliar viabilidade monetária de skills, frameworks, simuladores, cursos e workflows no Brasil.|tabela final, triangulação por canal, plano de teste 14 dias|
|CMD_AI_FIRST_72H_WEB_RESEARCH_AND_BACKLOG_V1|AI-First 72h Web Research and Backlog|Converter ideia em backlog priorizado por ROI, risco e dependência.|resumo 10 linhas, backlog 72h, automação por tarefa, top 5 pendências|
|CMD_OPUS_TO_CLAUDE_CODE_COMMAND_GENERATOR_V1|Opus to Claude Code Command Generator|Gerar comando técnico para Claude Code construir app React/JSX standalone.|VISUAL_REQUIREMENTS_SUMMARY, PRODUCT_SPEC_MINIMAL, EXECUTABLE_COMMAND_FOR_CLAUDE_CODE, QA_ACCEPTANCE_CHECKLIST|
|CMD_WEEKLY_PUBLISHING_ARTIFACT_TEST_V1|Weekly Publishing Artifact Test|Testar rota Artifact vs Inline para pacote editorial semanal.|WEEKLY_ARTIFACT_TEST_REPORT.md, D-026 atualizada, template domingo|