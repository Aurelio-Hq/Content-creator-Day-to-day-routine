# AI Gov Discovery Orchestrator — Standalone Skill

This is the corrected standalone version.

The complete Project Handoff V2 source is embedded inside the skill tree.

## What changed

The previous version had the JSON as a reference file but still behaved conceptually like an external reference system.

This version makes the package self-contained:

- `SKILL.md` = execution engine
- `TREEFILE.md` = internal navigation map
- `handoff_full_mece.json` = full machine-readable canonical source
- `PROJECT_HANDOFF_V2_CANONICAL.md` = full human-readable canonical source
- routing, gates, decisions, commands and trackers are separated into operational branches

## First command

```txt
/day-zero
```

or:

```txt
Estou no Dia Zero / Gate Zero. Ative a Skill standalone e use o documento canônico interno. Não peça upload externo.
```

## Core rule

Never ask Leonardo to upload or reference the original handoff document. It is already inside the package.
