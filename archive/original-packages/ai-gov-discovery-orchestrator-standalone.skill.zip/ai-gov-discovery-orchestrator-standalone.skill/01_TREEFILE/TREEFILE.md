# TREEFILE — AI Gov Discovery Orchestrator Standalone Skill

This Treefile is the internal navigation map for the Skill.

The skill is self-contained. The canonical document and JSON are inside the package.

## Load Order

1. `SKILL.md`
2. `01_TREEFILE/TREEFILE.md`
3. `02_ROUTING/ROUTER_RULES.md`
4. Only then load the needed canonical branch:
   - phases → `03_PHASES/PHASE_MAP.md`
   - gates → `04_GATES/GATES_AND_DONE.md`
   - decisions → `05_DECISIONS/DECISION_REGISTRY.md`
   - commands → `06_COMMANDS/LIVE_COMMANDS_INDEX.md`
   - full reconstruction → `00_CANONICAL_SOURCE/handoff_full_mece.json`

## Directory Map

```txt
ai-gov-discovery-orchestrator-standalone.skill/
├── SKILL.md
├── README.md
├── 00_CANONICAL_SOURCE/
│   ├── PROJECT_HANDOFF_V2_CANONICAL.md
│   └── handoff_full_mece.json
├── 01_TREEFILE/
│   ├── TREEFILE.md
│   └── TREEFILE.json
├── 02_ROUTING/
│   ├── ROUTER_RULES.md
│   └── LOOKUP_MAP.json
├── 03_PHASES/
│   └── PHASE_MAP.md
├── 04_GATES/
│   └── GATES_AND_DONE.md
├── 05_DECISIONS/
│   └── DECISION_REGISTRY.md
├── 06_COMMANDS/
│   └── LIVE_COMMANDS_INDEX.md
├── 07_TEMPLATES/
│   ├── GATE_TEMPLATE.md
│   ├── DOCUMENT_TEMPLATE.md
│   ├── TRACKER_TEMPLATE.md
│   └── NEXT_3_TASKS_TEMPLATE.md
├── 08_TRACKER/
│   ├── CURRENT_PHASE_TRACKER.md
│   └── NEXT_3_TASKS.md
├── 09_SCRIPTS/
│   ├── validate_skill_tree.py
│   └── init_discovery_vault.py
└── 99_EXPORTS/
```

## Routing Logic

| User intent | Load |
|---|---|
| Day Zero / Gate Zero | SKILL.md + TREEFILE + ROUTER_RULES + GATES_AND_DONE |
| Próximas 3 tarefas | CURRENT_PHASE_TRACKER + NEXT_3_TASKS |
| Decision check | DECISION_REGISTRY + canonical JSON branch |
| Generate command | LIVE_COMMANDS_INDEX |
| Rebuild full package | full MECE JSON + canonical markdown |
| Score portfolio | canonical JSON → discovery_exit_system → score criteria |
| Create vault | PHASE_MAP + scripts/init_discovery_vault.py |

## Rule

Never ask Leonardo to re-upload or reference the original handoff document. It is already embedded in this skill package.
