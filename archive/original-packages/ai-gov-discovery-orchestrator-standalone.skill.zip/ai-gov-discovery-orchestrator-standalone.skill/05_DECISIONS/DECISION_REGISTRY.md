# DECISION REGISTRY

|ID|Namespace|Decisão|Status|Confiança|Tags|
|---|---|---|---|---|---|
|D-001|Baseline|X-Ray deve preceder Skill Creator|Pré-tomada|Alto|#workflow #ai|
|D-002|Baseline|Consolidar múltiplos outputs em YAML integrado|Pré-tomada|Alto|#data #workflow|
|D-003|Baseline|Auditoria G22 deve rodar com gates|Pré-tomada|Alto|#strategy #validation|
|D-004|Baseline|Empower V4 é avaliador operacional|Pré-tomada|Médio|#ai #data|
|D-005|Baseline|Problema central é shipping, não conteúdo|Tomada|Alto|#execution #ops|
|D-006|Baseline|Suite de skills deve ser explicada para não-devs|Pré-tomada|Alto|#customer #product|
|D-007|Baseline|Método DK vira modelo editorial|Pré-tomada|Médio|#content #workflow|
|D-008|Baseline|eBook executivo deve ser decision-first|Tomada|Alto|#strategy #content|
|D-009|Baseline|Posts A/B devem virar mother pieces|Pré-tomada|Médio|#growth #content|
|D-010|Baseline|Data story deve seguir três atos|Pré-tomada|Alto|#data #content|
|D-011|Baseline|Vault Mode deve rotear por tipo/frame|Tomada|Alto|#workflow #strategy|
|D-012|Baseline|Gates light antes de executar análise pesada|Pré-tomada|Alto|#risk #decision|
|D-013|Baseline|A-Z Claude é tese de personalização estruturada|Pré-tomada|Alto|#ai #validation|
|D-014|Baseline|Blog deve seguir escaneabilidade + CTA|Tomada|Alto|#content #execution|
|D-015|Baseline|CMD editorial deve adaptar, não reescrever livremente|Tomada|Alto|#workflow #content|
|D-016|Baseline|Scripts Python exigem protocolo fixo|Tomada|Alto|#ops #workflow|
|D-017|Baseline|X-Ray artifacts precisam templates padronizados|Pré-tomada|Médio|#product #execution|
|D-018|Baseline|Design tokens editoriais governam capítulos|Pré-tomada|Alto|#content #workflow|
|D-019|Baseline|Skill deve empacotar dependências internas|Tomada|Alto|#ai #execution|
|D-020|Baseline|A-Z deve combinar 4D Anthropic + 5D Leonardo|Pré-tomada|Alto|#ai #product|
|D-021|Design|Identidade visual proprietária minimalista|Pré-tomada|Alta|#brand #content #workflow|
|D-022|Design|Não gerar visual do zero a cada publicação|Pré-tomada|Alta|#ops #content #execution|
|D-023|Design|Weekly Publishing Artifact|Pré-tomada|Média-alta|#content #workflow #growth|
|D-024|Design|iPad-first como padrão de produção|Pré-tomada|Alta|#ops #content #workflow|
|D-025|Design|GitHub como fonte dos metadados editoriais|Pré-tomada|Alta|#github #data #content|
|D-026|Design|Avaliar Artifact vs Inline Conversation Output|Pré-tomada|Média|#workflow #validation #product|
|D-027|Design|Project específico para Design/Publishing System|Pré-tomada|Baixa-média|#project #content #ops|
|D-028|Design|Estilo didático com exemplo visual obrigatório|Pré-tomada|Alta|#content #education #workflow #brand|
|D-029|Editorial|Usar estrutura editorial estilo DK Philosophy|Pré-tomada|Alta|#content #brand #education #design|
|D-030|Editorial|Usar dashboards visuais para benchmarks|Pré-tomada|Alta|#data #validation #content #workflow|
|D-031|Brand Language|Reposicionar “prompt” como “comando”|Pré-tomada|Alto|#brand #ai #workflow #education|
|D-032|Brand Language|Trocar “chat” por “interação”|Pré-tomada|Alto|#brand #ai #workflow|
|D-033|Brand Language|Trocar “tarefa isolada” por “workflow inteligente”|Pré-tomada|Alto|#workflow #education #execution|
|D-034|Proprietary Concepts|Inside Claude Mind / Open Claude Mind|Pré-tomada|Alta|#brand #education #ai #workflow|
|D-035|Proprietary Concepts|Learning by Watching the Model|Pré-tomada|Alta|#education #ai #workflow|
|D-036|Proprietary Concepts|Execute Language Assertive / Avoid Rework|Pré-tomada|Alta|#workflow #execution #ai|
|D-037|Proprietary Concepts|Cognitive Frameworks + Scaffolding|Pré-tomada|Alta|#framework #workflow #education|
|D-038|Proprietary Concepts|ETC Universe|Pré-tomada|Alta|#ai #education #prompting #workflow|
|D-039|Bash-like Commands|Bash-like AI Commands|Pré-tomada|Alta|#ai #workflow #execution|
|D-040|Bash-like Commands|Comando comprimido com semântica operacional|Pré-tomada|Alta|#workflow #ai #ops|
|D-041|Research Case|Palantir/Copilot como case de pesquisa estruturada|Pré-tomada|Média-alta|#research #ai #strategy|
|D-041B|Editorial Persistent|Estrutura narrativa seguirá referência Harvard Business Review Press|Pré-tomada|Alto|#content #strategy #product #workflow|