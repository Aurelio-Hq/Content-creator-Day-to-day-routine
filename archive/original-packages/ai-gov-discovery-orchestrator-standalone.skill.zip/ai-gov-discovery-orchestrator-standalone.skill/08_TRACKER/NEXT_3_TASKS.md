# NEXT 3 TASKS — DAY ZERO

CURRENT_PHASE: P0 — Intake / Freeze  
CURRENT_STEP: S0 — Gate Zero  
LAST_OUTPUT: Standalone skill package created  
NEXT_GATE: GATE P0.S0.G0  

## NEXT_3_TASKS

1. Confirmar Opção A no Gate Zero: Standalone Skill + Document Factory.
2. Rodar `/day-zero` no Claude com a skill instalada.
3. Gerar `PROJECT_USER_MESSAGE.md` como primeiro documento operacional.

## TRACKER_UPDATE

| Phase | Step | Output | Status | Last Decision | Next Gate | Next Document |
|---|---|---|---|---|---|---|
| P0 | S0 | Gate Zero | Ready | — | GATE P0.S0.G0 | PROJECT_USER_MESSAGE.md |
