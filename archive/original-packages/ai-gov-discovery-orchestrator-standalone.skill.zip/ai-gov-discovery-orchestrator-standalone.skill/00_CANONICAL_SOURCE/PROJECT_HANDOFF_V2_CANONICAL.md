# AI GOV BRASIL — PROJECT HANDOFF V2 — CANONICAL STANDALONE

> Documento canônico interno da Skill.  
> Esta versão é standalone: não exige upload externo do documento original para operar.

| Campo | Valor |
|---|---|
| Owner | Leonardo |
| Package | ai-gov-discovery-orchestrator-standalone.skill |
| Source | PROJECT HANDOFF V2 · V-20260521 · BUILD 018 |
| Generated | 2026-05-22 |
| Status | Active |
| Operating Mode | Single Conversation Document Factory |
| Current Phase | P0/P1 transition — começar pelo Gate Zero |

---

## 0. MECE INDEX

|ID|Seção|Conteúdo|
|---|---|---|
|SEC-00|VERSION REGISTRY|Tabela mestre de entradas V-YYYYMMDD-### e rastreabilidade de comandos incluídos.|
|SEC-01|PROJECT HANDOFF PROTOCOL|CMD_V2 para fábrica documental em conversa única, com fases, gates, decisões e outputs.|
|SEC-02|DISCOVERY EXIT SYSTEM|Sistema de saída do Discovery: corpus → inventário → indexação → timeline → deduplicação → score → MVP → publicação.|
|SEC-03|GATE SYSTEM & DONE DEFINITIONS|Gates G-001–G-009, garfos de decisão e automação por tipo de tarefa.|
|SEC-04|DECISION REGISTRY|Decisões D-001–D-041, subdecisões, premissas, riscos e baseline operacional.|
|SEC-05|BRAND ARCHITECTURE|Arquitetura AI Gov Brasil como marca-mãe e Inside Claude’s Mind como produto/série.|
|SEC-06|EXECUTION WORKFLOWS|Workflow 72h, automação ROI, sprint mínimo e próximas ações.|
|SEC-07|CLAUDE ROUTINES|10 rotinas Claude por conta/função: digest, tarefas, métricas, vault, GitHub, publicação, score e watchlist.|
|SEC-08|DESIGN SYSTEM & PUBLISHING|Identidade visual iPad-first, Artifact vs Inline, templates editoriais DK e visual grammar.|
|SEC-09|MARKET RESEARCH & MONETIZATION|Score de viabilidade Brasil 2026, simulação educacional e método de monetização.|
|SEC-10|PRODUCT — ONBOARDING SIMULATOR|Escopo, módulos, exportação JSON, componentes React e requisitos técnicos.|
|SEC-11|PROPRIETARY FRAMEWORKS|Prompt→Comando→Workflow, Inside Claude Mind, ETC Universe e linguagem de marca.|
|SEC-12|BASH-LIKE COMMANDS|Fórmula, anatomia, exemplos e Cognitive Framework Router.|
|SEC-13|LIVE COMMANDS INDEX|CMDs prontos para colar: Project Handoff, Discovery Vault, Market Research, 72h Backlog, Claude Code, Weekly Artifact.|
|SEC-14|NEXT 3 TASKS & TRACKER|Estado atual, próximas três tarefas, tracker inline e apêndice.|

---

## 1. VERSION REGISTRY

|ID|Título|Type|Status|Tags|CMD|
|---|---|---|---|---|---|
|V-20260521-001|Claude Onboarding Simulator Command|Task|Active|#ai #product #workflow|CMD_OPUS_TO_CLAUDE_CODE_COMMAND_GENERATOR_V1|
|V-20260521-001B|Decisões Pré-Tomadas — 42 Docs (D-001–D-041)|Decision|Validating|#decision #workflow|—|
|V-20260521-002|Pesquisa Viabilidade Monetária Skills Claude|Analysis|Active|#market #validation|CMD_MARKET_MONETIZATION_TRIANGULATION_BRASIL_2026_V1|
|V-20260521-003|Brand Architecture: AI Gov Brasil vs Inside Claude’s Mind|Decision|Decision|#strategy #brand|—|
|V-20260521-004|72h Progressive Dependency Workflow|Plan|Active|#execution #workflow|—|
|V-20260521-005|AI-First 72h Solo Operator Workflow|Decision|Active|#execution #ai|—|
|V-20260521-006|AI-First Solo Operator 72h Automation ROI|Decision|Active|#workflow #execution|CMD_AI_FIRST_72H_WEB_RESEARCH_AND_BACKLOG_V1|
|V-20260521-007|Discovery Exit System: Corpus → Database → MVP Decision|Decision|Active|#workflow #data|CMD_DISCOVERY_EXIT_VAULT_BUILDER_V1|
|V-20260521-008|Discovery Vault ZIP + 72h AI-First Sorting Workflow|Task|Active|#workflow #data|CMD_DISCOVERY_VAULT_SORT_AND_SCORE_V1|
|V-20260521-009|Project User Message Handoff to Claude Reasoning|Task|Active|#workflow #project|CMD_PROJECT_HANDOFF_REASONING_OPEN_V1|
|V-20260521-010|Discovery Exit Delta Gates Map|Reference|Active|#workflow #validation|—|
|V-20260521-011|Discovery Exit Macro Map (Mermaid)|Reference|Active|#workflow #validation|—|
|V-20260521-012|Decisões: Canais, Rotina, Hotmart e Stack Claude (D-002–D-019)|Decision|Active|#strategy #execution|—|
|V-20260521-013|Rotinas Claude Estratégicas — 10 Slots|Decision|Active|#workflow #automation|R-001–R-010|
|V-20260521-014|Design System + Weekly Publishing Artifact (D-021–D-027)|Decision|Active|#content #workflow|CMD_WEEKLY_PUBLISHING_ARTIFACT_TEST_V1|
|V-20260521-015|Formato Editorial DK + Dashboard Visual (D-029–D-030)|Decision|Active|#content #brand|—|
|V-20260521-016|Conceitos Proprietários: Inside Claude Mind, Execute Language, ETC Universe (D-034–D-038)|Decision|Active|#brand #education|—|
|V-20260521-017|Bash-like Commands + Cognitive Router + Palantir Extraction (D-039–D-041, SK-001)|Decision|Active|#ai #workflow|—|
|V-20260521-018|Project Handoff V2: Single Conversation Document Factory|Task|Active|#workflow #project|CMD_PROJECT_HANDOFF_REASONING_OPEN_V2|

---

## 2. PROJECT HANDOFF PROTOCOL

**Missão:** Parceiro estrutural de Leonardo: organização, decisão, geração documental.

**Loop operacional:**

```txt
INTERAÇÃO → GATE → DECISÃO → DOCUMENTO → TRACKER → PRÓXIMAS 3 TAREFAS
```

### Regras centrais

- Não resumir superficialmente
- Não criar novos produtos antes de estabilizar o Discovery Vault
- Não validar pela opinião da IA
- Usar critérios, evidências, scorecards e gates
- Separar Leonardo / GPT / Claude / Decisão Operacional
- Separar FACT / INFERENCE / HYPOTHESIS / GAP / DECISION
- Numerar fases, etapas, tarefas, decisões e outputs
- Sempre indicar fase atual, etapa atual e próximo documento
- Sempre terminar com Próximas 3 tarefas
- Toda tarefa deve gerar arquivo, decisão, índice, score, memo ou checklist
- Se houver ambiguidade, apresentar no máximo 2 opções principais
- Se uma opção for recomendada, explicar por quê em até 5 linhas
- Leonardo decide gates sensíveis

### Documentos a gerar

|Grupo|ID|Arquivo|
|---|---|---|
|Núcleo|DOC-001|PROJECT_USER_MESSAGE.md|
|Núcleo|DOC-002|PROJECT_MANIFESTO.md|
|Núcleo|DOC-003|MASTER_ACTION_UNIT.md|
|Núcleo|DOC-004|PHASED_WORKFLOW_MAP.md|
|Núcleo|DOC-005|NEXT_3_TASKS_PROTOCOL.md|
|Discovery Exit|DOC-006|DISCOVERY_EXIT_MAP.md|
|Discovery Exit|DOC-007|DISCOVERY_GATES_AND_DONE.md|
|Discovery Exit|DOC-008|DISCOVERY_VAULT_OPERATING_SYSTEM.md|
|Discovery Exit|DOC-009|CORPUS_INDEXING_PROTOCOL.md|
|Discovery Exit|DOC-010|CANONICAL_VERSION_PROTOCOL.md|
|Decisões e marca|DOC-011|PRE_TAKEN_DECISIONS.md|
|Decisões e marca|DOC-012|BRAND_ARCHITECTURE.md|
|Decisões e marca|DOC-013|PROPRIETARY_CONCEPTS.md|
|Decisões e marca|DOC-014|EDITORIAL_STYLE_SYSTEM.md|
|Decisões e marca|DOC-015|DESIGN_TOKENS_AND_VISUAL_LANGUAGE.md|
|Produto e monetização|DOC-016|PRODUCT_PORTFOLIO_SCORECARD.md|
|Produto e monetização|DOC-017|MVP_CANDIDATES_DECISION_MEMO.md|
|Produto e monetização|DOC-018|HOTMART_ASSET_PLAN.md|
|Produto e monetização|DOC-019|PUBLICATION_PIPELINE_60_DAYS.md|
|Produto e monetização|DOC-020|MONETIZATION_PATHWAYS.md|
|Operação|DOC-021|CLAUDE_ACCOUNT_OPERATING_MODEL.md|
|Operação|DOC-022|GITHUB_SOURCE_OF_TRUTH_PROTOCOL.md|
|Operação|DOC-023|ROUTINES_AUTOMATION_PLAN.md|
|Operação|DOC-024|WEEKLY_PUBLISHING_ARTIFACT_PROTOCOL.md|
|Operação|DOC-025|WORKBOOK_60_DAYS_SPEC.md|

### Status inicial

```yaml
CURRENT_PHASE: P1 — Organização Digital / Discovery Vault Setup
CURRENT_STEP: S1 — Centralização do corpus
CURRENT_OBJECTIVE: Transformar corpus disperso em base documental de decisão
NEXT_DOCUMENT: PROJECT_USER_MESSAGE.md
```

---

## 3. DISCOVERY EXIT SYSTEM

### Diagnóstico

```json
{
  "research": "6 meses de Discovery; corpus grande, disperso.",
  "products": "Skills, cursos, e-books, posts, comandos e simuladores sem ranking decisório.",
  "infra": "12 contas Claude, PC, GitHub, arquivos exportados sem índice único.",
  "strategy": "Teses e ICPs competindo entre si.",
  "execution": "Pronto para publicar, mas sem gate Discovery → MVP."
}
```

### Fluxo

```txt
CORPUS DOCUMENTAL → INVENTÁRIO → INDEXAÇÃO → LINHA DO TEMPO → EXTRAÇÃO DE ENTIDADES → DEDUPLICAÇÃO → SCORE DE PORTFÓLIO → DECISÃO MVP → PUBLICAÇÃO
```

### Fases

|Phase|Name|Objective|Output|
|---|---|---|---|
|P0|Intake / Freeze|Congelar criação nova e instalar Discovery Vault|PROJECT_USER_MESSAGE.md, PROJECT_MANIFESTO.md|
|P1|Organização Digital / Discovery Vault|Centralizar arquivos no Discovery Vault|DISCOVERY_VAULT_OPERATING_SYSTEM.md|
|P2|Indexação|Transformar arquivos em base de dados|MASTER_INDEX.csv, ASSET_REGISTRY.csv, CORPUS_INDEXING_PROTOCOL.md|
|P3|Timeline / Evolução|Reconstruir evolução real do projeto|TIMELINE_DISCOVERY.md, DISCOVERY_EXIT_MAP.md|
|P4|Deduplicação / Canônicos|Separar versões atuais, duplicadas e superseded|CANONICAL_MAP.csv, SUPERSEDED_LIST.csv|
|P5|Score de Portfólio|Ranquear famílias de produto|PRODUCT_PORTFOLIO.csv, MVP_CANDIDATES.csv|
|P6|Decisão MVP|Escolher Top 3 candidatos a MVP|MVP_DECISION_MEMO.md|
|P7|Publication Pipeline|Escolher Top 5 conteúdos publish-first|CONTENT_INVENTORY.csv, PUBLICATION_QUEUE.md|
|P8|Validação Pública|Obter sinais reais de demanda externa|VALIDATION_REPORT.md|
|P9|Next Sprint|Backlog de 7 dias baseado em evidência|7_DAY_BACKLOG.md, CURRENT_PHASE_TRACKER.md|

### Estrutura de pastas

|Path|Função|
|---|---|
|00_INBOX_DROPZONE|Entrada bruta; arrastar arquivos sem pensar demais.|
|01_RAW_EXPORTS|Preservar fontes originais: Claude, outras IAs, PC, GitHub, screenshots.|
|01A_CLAUDE_EXPORTS|Exports das contas Claude.|
|01C_LOCAL_PC_FILES|Arquivos locais.|
|01D_GITHUB_REPOS|Repositórios.|
|01E_SCREENSHOTS_MEDIA|Prints e mídia.|
|02_INDEX_REGISTRY|CSVs, taxonomia e scorecard.|
|03_TIMELINE_DISCOVERY|Linha do tempo dos seis meses.|
|04_PRODUCT_PORTFOLIO|Famílias comerciais e produtos.|
|05_SKILLS_COMMANDS|Skills e comandos.|
|06_CONTENT_LIBRARY|Artigos, vídeos, posts e cursos.|
|07_RESEARCH_EVIDENCE|Evidências e fontes.|
|08_DECISIONS_RISKS|Decisões e riscos.|
|09_MVP_CANDIDATES|Candidatos fortes.|
|10_PUBLICATION_PIPELINE|Fila pública.|
|11_LEGAL_BRAND_COMPLIANCE|Domínio, licença, disclaimers.|
|12_ARCHIVE_SUPERSEDED|Duplicatas e versões antigas.|
|99_EXPORTS_REPORTS|Relatórios finais.|

### Score de portfólio

|Critério|Peso|
|---|---|
|Clareza do ICP|20|
|Pronto para publicar|15|
|Evidência externa|15|
|Diferenciação|15|
|Facilidade solo|15|
|Monetização provável|10|
|Risco legal/marca|10|

### Score → decisão

|Score|Decisão|
|---|---|
|80–100|MVP NOW|
|65–79|PUBLISH FIRST|
|50–64|VALIDATE|
|35–49|INCUBATE|
|0–34|ARCHIVE / KILL|

---

## 4. GATES

|Gate|Done Definition|
|---|---|
|G-001|Corpus relevante centralizado|
|G-002|Arquivos principais indexados|
|G-003|Timeline real reconstruída|
|G-004|Versões canônicas definidas|
|G-005|Portfólio com score|
|G-006|Top 3 MVP candidates definidos|
|G-007|Top 5 conteúdos publish-first definidos|
|G-008|1 teste público pronto ou em execução|
|G-009|Backlog de 7 dias definido|

---

## 5. DECISION REGISTRY

|ID|Namespace|Decisão|Status|Confiança|Tags|
|---|---|---|---|---|---|
|D-001|Baseline|X-Ray deve preceder Skill Creator|Pré-tomada|Alto|#workflow #ai|
|D-002|Baseline|Consolidar múltiplos outputs em YAML integrado|Pré-tomada|Alto|#data #workflow|
|D-003|Baseline|Auditoria G22 deve rodar com gates|Pré-tomada|Alto|#strategy #validation|
|D-004|Baseline|Empower V4 é avaliador operacional|Pré-tomada|Médio|#ai #data|
|D-005|Baseline|Problema central é shipping, não conteúdo|Tomada|Alto|#execution #ops|
|D-006|Baseline|Suite de skills deve ser explicada para não-devs|Pré-tomada|Alto|#customer #product|
|D-007|Baseline|Método DK vira modelo editorial|Pré-tomada|Médio|#content #workflow|
|D-008|Baseline|eBook executivo deve ser decision-first|Tomada|Alto|#strategy #content|
|D-009|Baseline|Posts A/B devem virar mother pieces|Pré-tomada|Médio|#growth #content|
|D-010|Baseline|Data story deve seguir três atos|Pré-tomada|Alto|#data #content|
|D-011|Baseline|Vault Mode deve rotear por tipo/frame|Tomada|Alto|#workflow #strategy|
|D-012|Baseline|Gates light antes de executar análise pesada|Pré-tomada|Alto|#risk #decision|
|D-013|Baseline|A-Z Claude é tese de personalização estruturada|Pré-tomada|Alto|#ai #validation|
|D-014|Baseline|Blog deve seguir escaneabilidade + CTA|Tomada|Alto|#content #execution|
|D-015|Baseline|CMD editorial deve adaptar, não reescrever livremente|Tomada|Alto|#workflow #content|
|D-016|Baseline|Scripts Python exigem protocolo fixo|Tomada|Alto|#ops #workflow|
|D-017|Baseline|X-Ray artifacts precisam templates padronizados|Pré-tomada|Médio|#product #execution|
|D-018|Baseline|Design tokens editoriais governam capítulos|Pré-tomada|Alto|#content #workflow|
|D-019|Baseline|Skill deve empacotar dependências internas|Tomada|Alto|#ai #execution|
|D-020|Baseline|A-Z deve combinar 4D Anthropic + 5D Leonardo|Pré-tomada|Alto|#ai #product|
|D-021|Design|Identidade visual proprietária minimalista|Pré-tomada|Alta|#brand #content #workflow|
|D-022|Design|Não gerar visual do zero a cada publicação|Pré-tomada|Alta|#ops #content #execution|
|D-023|Design|Weekly Publishing Artifact|Pré-tomada|Média-alta|#content #workflow #growth|
|D-024|Design|iPad-first como padrão de produção|Pré-tomada|Alta|#ops #content #workflow|
|D-025|Design|GitHub como fonte dos metadados editoriais|Pré-tomada|Alta|#github #data #content|
|D-026|Design|Avaliar Artifact vs Inline Conversation Output|Pré-tomada|Média|#workflow #validation #product|
|D-027|Design|Project específico para Design/Publishing System|Pré-tomada|Baixa-média|#project #content #ops|
|D-028|Design|Estilo didático com exemplo visual obrigatório|Pré-tomada|Alta|#content #education #workflow #brand|
|D-029|Editorial|Usar estrutura editorial estilo DK Philosophy|Pré-tomada|Alta|#content #brand #education #design|
|D-030|Editorial|Usar dashboards visuais para benchmarks|Pré-tomada|Alta|#data #validation #content #workflow|
|D-031|Brand Language|Reposicionar “prompt” como “comando”|Pré-tomada|Alto|#brand #ai #workflow #education|
|D-032|Brand Language|Trocar “chat” por “interação”|Pré-tomada|Alto|#brand #ai #workflow|
|D-033|Brand Language|Trocar “tarefa isolada” por “workflow inteligente”|Pré-tomada|Alto|#workflow #education #execution|
|D-034|Proprietary Concepts|Inside Claude Mind / Open Claude Mind|Pré-tomada|Alta|#brand #education #ai #workflow|
|D-035|Proprietary Concepts|Learning by Watching the Model|Pré-tomada|Alta|#education #ai #workflow|
|D-036|Proprietary Concepts|Execute Language Assertive / Avoid Rework|Pré-tomada|Alta|#workflow #execution #ai|
|D-037|Proprietary Concepts|Cognitive Frameworks + Scaffolding|Pré-tomada|Alta|#framework #workflow #education|
|D-038|Proprietary Concepts|ETC Universe|Pré-tomada|Alta|#ai #education #prompting #workflow|
|D-039|Bash-like Commands|Bash-like AI Commands|Pré-tomada|Alta|#ai #workflow #execution|
|D-040|Bash-like Commands|Comando comprimido com semântica operacional|Pré-tomada|Alta|#workflow #ai #ops|
|D-041|Research Case|Palantir/Copilot como case de pesquisa estruturada|Pré-tomada|Média-alta|#research #ai #strategy|
|D-041B|Editorial Persistent|Estrutura narrativa seguirá referência Harvard Business Review Press|Pré-tomada|Alto|#content #strategy #product #workflow|

---

## 6. BRAND ARCHITECTURE

```json
{
  "parent_brand": "AI Governance Brasil / AI Gov Brasil",
  "product_subbrand": "Inside Claude’s Mind",
  "avoid": [
    "Inside Cloud Mind",
    "insideclaude.com como domínio principal sem cautela"
  ],
  "recommended_url_pattern": "aigovbrasil.com/inside-claude",
  "disclaimer": "Conteúdo educacional independente. Não afiliado, patrocinado ou endossado pela Anthropic.",
  "architecture": [
    "AI Governance Brasil",
    "Inside Claude’s Mind",
    "Claude Workflow Guides",
    "AI Literacy for Work",
    "Governance Readiness",
    "Business Thesis Vault / Decision OS"
  ]
}
```

---

## 7. EXECUTION WORKFLOWS

```json
{
  "72h_progressive_dependency": [
    "Decisão de marca",
    "domínio",
    "arquitetura pública",
    "comando Claude Code",
    "MVP simulador",
    "landing",
    "conteúdo de lançamento",
    "teste de demanda",
    "decisão monetária inicial"
  ],
  "automation_roi_verdict": "Melhor ROI é web research + síntese + backlog + artefatos prontos; humano executa contas, pagamentos, permissões e publicação final.",
  "minimum_sprint_backlog": [
    "Confirmar marca e comprar domínio principal",
    "Criar Project Claude + instruções + estrutura de docs",
    "Criar Skills Product Self-Knowledge e Brand Guidelines",
    "Gerar one-page offer + landing + FAQ + lead magnet",
    "Abrir shell do produto na Kiwify/Hotmart",
    "Publicar 1 post LinkedIn + 1 vídeo/roteiro YouTube",
    "Capturar 10 sinais de mercado",
    "Escrever PRD do simulador e regra de export JSON"
  ]
}
```

---

## 8. CLAUDE ROUTINES

|ID|Rotina|Frequência|Decisão|
|---|---|---|---|
|R-001|Claude + LLM Intelligence Digest|Diária|Ativar|
|R-002|Morning Next 3 Tasks|Diária|Ativar|
|R-003|Evening Metrics + Signals Review|Diária|Ativar semi-manual|
|R-004|Discovery Vault Index Reminder|3x semana|Ativar|
|R-005|Weekly Strategy Decision Memo|Semanal|Ativar|
|R-006|GitHub Repo Health Check|3x semana|Ativar|
|R-007|Blog-to-Multiformat Draft Queue|2x semana|Ativar|
|R-008|Product Readiness Score|Semanal|Ativar|
|R-009|Public Source Watchlist|Semanal|Ativar|
|R-010|Asset Build Queue|Semanal|Ativar|

---

## 9. DESIGN SYSTEM

```json
{
  "identity": [
    "minimalista",
    "iPad-first",
    "coding aesthetic",
    "Obsidian-like",
    "plain text",
    "Mermaid",
    "finelines",
    "blocos limpos"
  ],
  "route_decision": "Modelo híbrido — Artifact para batch semanal e materiais visuais; Inline para posts rápidos e comandos operacionais.",
  "editorial_template_fields": [
    "TEMA",
    "BRIEFING",
    "EXEMPLO",
    "VISUAL",
    "COMO USAR",
    "OUTPUT ESPERADO"
  ],
  "dk_template_fields": [
    "HEADLINE",
    "SUBHEAD",
    "IN CONTEXT",
    "MENTAL MAP",
    "SUPPORT TEXT",
    "FINAL TAKEAWAY"
  ]
}
```

---

## 10. MARKET RESEARCH & MONETIZATION

```json
{
  "channels": [
    "Infoproduto / curso",
    "B2B workshop",
    "B2C app/template",
    "B2B SaaS",
    "B2B2C parceria",
    "Conteúdo/audiência"
  ],
  "simulator_consolidated_confidence": "73% — boa tese para validação, não para escalar sem teste.",
  "monetization_formula": {
    "Demanda": 25,
    "Disposição a Pagar": 20,
    "Distribuição": 20,
    "Diferenciação": 15,
    "Execução Solo": 10,
    "Risco Invertido": 10
  }
}
```

---

## 11. PRODUCT — ONBOARDING SIMULATOR

```json
{
  "name": "Claude Onboarding Simulator",
  "type": "Simulador educacional — não produto oficial da Anthropic",
  "technology": "React/JSX standalone, mobile-first, responsivo",
  "persistence": "localStorage",
  "backend": "Não obrigatório",
  "modules": [
    "Onboarding",
    "Home / Chat",
    "Perfil e Preferências",
    "Projetos",
    "Estilos de Resposta",
    "Skills",
    "Conectores e Permissões",
    "Artefatos",
    "Claude Code / Workspace"
  ],
  "export_schema": [
    "user_profile",
    "personal_preferences",
    "response_styles",
    "projects",
    "project_instructions",
    "skills",
    "connectors",
    "permissions",
    "model_preferences",
    "tool_preferences",
    "generated_claude_command"
  ],
  "required_components": [
    "AppShell",
    "Sidebar",
    "MobileTopBar",
    "BottomSheet",
    "Modal",
    "Card",
    "Toggle",
    "FormField",
    "ProjectBuilder",
    "StyleBuilder",
    "SkillBuilder",
    "ConnectorPanel",
    "ExportPanel",
    "ArtifactGallery"
  ]
}
```

---

## 12. PROPRIETARY FRAMEWORKS

```json
{
  "central_reframe": {
    "from": [
      "prompt",
      "chat",
      "task"
    ],
    "to": [
      "comando",
      "interação",
      "workflow inteligente"
    ]
  },
  "brand_language_use": [
    "comando",
    "interação",
    "workflow inteligente",
    "output auditável",
    "gate",
    "done definition",
    "sistema de trabalho"
  ],
  "avoid_as_core": [
    "prompt mágico",
    "chat com IA",
    "tarefa solta",
    "hack de produtividade"
  ],
  "slogans": [
    "Não escreva prompts. Estruture comandos.",
    "Não converse com IA. Conduza interações.",
    "Não automatize tarefas. Desenhe workflows inteligentes."
  ]
}
```

---

## 13. BASH-LIKE COMMANDS

```json
{
  "formula": "[VERBO] / [FONTE] / [OBJETO] / [AÇÃO] / [MÉTODO] / [ESTRUTURA] / [LIMITE] / [FRAMEWORK] / [OUTPUT]",
  "examples": [
    "search /vault/raw_exports /scan /mece /topdown /master_index /500words /use5w2h /output-md",
    "scan corpus /dedup /timeline /score /top3mvp /output csv+md"
  ],
  "router": {
    "id": "SK-001",
    "name": "Cognitive Framework Router",
    "intent_to_frameworks": {
      "Pesquisa": [
        "MECE",
        "SCQA",
        "evidence hierarchy"
      ],
      "Decisão": [
        "Cynefin",
        "trade-off matrix",
        "risk register"
      ],
      "Planejamento": [
        "Working Backwards",
        "5W2H",
        "RACI"
      ],
      "Diagnóstico": [
        "3P",
        "Ishikawa",
        "Theory of Constraints"
      ]
    }
  }
}
```

---

## 14. LIVE COMMANDS INDEX

|ID|Nome|Finalidade|Outputs|
|---|---|---|---|
|CMD_PROJECT_HANDOFF_REASONING_OPEN_V2|Project Handoff V2|Operar a conversa como Single Conversation Document Factory + Decision Gates.|diagnóstico, mapa de fases, documentos, gate, próximas 3 tarefas|
|CMD_PROJECT_HANDOFF_REASONING_OPEN_V1|Project Handoff V1|Escanear conversa exportada e gerar cinco documentos operacionais iniciais.|PROJECT_USER_MESSAGE.md, PROJECT_MANIFESTO.md, MASTER_ACTION_UNIT.md, PHASED_WORKFLOW_MAP.md, NEXT_3_TASKS_PROTOCOL.md|
|CMD_DISCOVERY_EXIT_VAULT_BUILDER_V1|Discovery Exit Vault Builder|Transformar corpus disperso em base de decisão para sair de Discovery.|índices CSV, score de portfólio, top 3 MVP, top 5 conteúdos, backlog 7 dias|
|CMD_MARKET_MONETIZATION_TRIANGULATION_BRASIL_2026_V1|Market Monetization Triangulation|Avaliar viabilidade monetária de skills, frameworks, simuladores, cursos e workflows no Brasil.|tabela final, triangulação por canal, plano de teste 14 dias|
|CMD_AI_FIRST_72H_WEB_RESEARCH_AND_BACKLOG_V1|AI-First 72h Web Research and Backlog|Converter ideia em backlog priorizado por ROI, risco e dependência.|resumo 10 linhas, backlog 72h, automação por tarefa, top 5 pendências|
|CMD_OPUS_TO_CLAUDE_CODE_COMMAND_GENERATOR_V1|Opus to Claude Code Command Generator|Gerar comando técnico para Claude Code construir app React/JSX standalone.|VISUAL_REQUIREMENTS_SUMMARY, PRODUCT_SPEC_MINIMAL, EXECUTABLE_COMMAND_FOR_CLAUDE_CODE, QA_ACCEPTANCE_CHECKLIST|
|CMD_WEEKLY_PUBLISHING_ARTIFACT_TEST_V1|Weekly Publishing Artifact Test|Testar rota Artifact vs Inline para pacote editorial semanal.|WEEKLY_ARTIFACT_TEST_REPORT.md, D-026 atualizada, template domingo|

---

## 15. CURRENT TRACKER

|Phase|Step|Output|Status|Last Decision|Next Gate|Next Document|
|---|---|---|---|---|---|---|
|P1|S1|Vault setup|Not started|—|G-001|PROJECT_USER_MESSAGE.md|
|P2|S1|MASTER_INDEX.csv|Pending P1|—|G-002|CORPUS_INDEXING_PROTOCOL.md|

---

## 16. NEXT 3 TASKS

|ID|Tarefa|Done|Output|Dependência|
|---|---|---|---|---|
|P1.S1.T1|Instalar o Discovery Vault|ZIP baixado + pasta criada + README lido + estrutura preservada|Vault no PC|Nenhuma|
|P1.S1.T2|Centralizar corpus bruto|Exports Claude em 01A · GitHub em 01D · PC files em 01C · Prints em 01E · não classificados em 00|Estrutura preenchida|P1.S1.T1|
|P2.S1.T1|Rodar primeiro índice com Claude|MASTER_INDEX.csv iniciado · ASSET_REGISTRY.csv iniciado · ≥30–50 ativos catalogados · next_action atribuído|MASTER_INDEX.csv + ASSET_REGISTRY.csv|P1.S1.T2|

---

## 17. APPENDIX NEXT STEPS

|ID|Tarefa|Output|
|---|---|---|
|T-001|Enviar o YAML completo Palantir/Copilot, se existir|Extração completa do case|
|T-002|Criar biblioteca BASH_LIKE_AI_COMMANDS.md|20 comandos curtos reutilizáveis|
|T-003|Vincular Cognitive Framework Router ao Discovery Vault|SKILLS_INVENTORY.csv atualizado|

---

## 18. OPERATING RULE

This document is the canonical internal source for the Skill.  
When in doubt, use `00_CANONICAL_SOURCE/handoff_full_mece.json` as the machine-readable source and this Markdown file as the human-readable source.
