#!/usr/bin/env python3
from pathlib import Path

folders = [
    "00_INBOX_DROPZONE",
    "01_RAW_EXPORTS/01A_CLAUDE_EXPORTS",
    "01_RAW_EXPORTS/01C_LOCAL_PC_FILES",
    "01_RAW_EXPORTS/01D_GITHUB_REPOS",
    "01_RAW_EXPORTS/01E_SCREENSHOTS_MEDIA",
    "02_INDEX_REGISTRY",
    "03_TIMELINE_DISCOVERY",
    "04_PRODUCT_PORTFOLIO",
    "05_SKILLS_COMMANDS",
    "06_CONTENT_LIBRARY",
    "07_RESEARCH_EVIDENCE",
    "08_DECISIONS_RISKS",
    "09_MVP_CANDIDATES",
    "10_PUBLICATION_PIPELINE",
    "11_LEGAL_BRAND_COMPLIANCE",
    "12_ARCHIVE_SUPERSEDED",
    "99_EXPORTS_REPORTS",
]

base = Path.cwd() / "AI-GOV-BRASIL-DISCOVERY-VAULT"
for folder in folders:
    (base / folder).mkdir(parents=True, exist_ok=True)

(base / "README.md").write_text("# AI Gov Brasil Discovery Vault\n\nInitialized by standalone skill.\n", encoding="utf-8")
print(base)
