#!/usr/bin/env python3
from pathlib import Path
import json, sys

root = Path(__file__).resolve().parents[1]

required = [
    "SKILL.md",
    "README.md",
    "01_TREEFILE/TREEFILE.md",
    "01_TREEFILE/TREEFILE.json",
    "00_CANONICAL_SOURCE/handoff_full_mece.json",
    "00_CANONICAL_SOURCE/PROJECT_HANDOFF_V2_CANONICAL.md",
    "02_ROUTING/ROUTER_RULES.md",
    "04_GATES/GATES_AND_DONE.md",
]

missing = [p for p in required if not (root / p).exists()]
if missing:
    print("Missing files:")
    for p in missing:
        print("-", p)
    sys.exit(1)

skill = (root / "SKILL.md").read_text(encoding="utf-8")
if not skill.startswith("---") or "name:" not in skill or "description:" not in skill:
    print("SKILL.md frontmatter invalid.")
    sys.exit(1)

with open(root / "00_CANONICAL_SOURCE/handoff_full_mece.json", "r", encoding="utf-8") as f:
    data = json.load(f)

for key in ["package_metadata", "mece_index", "decision_registry"]:
    if key not in data:
        print(f"Canonical JSON missing key: {key}")
        sys.exit(1)

print("Standalone skill tree validation passed.")
