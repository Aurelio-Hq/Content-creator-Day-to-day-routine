# GATES AND DONE DEFINITIONS

## GATE P0.S0.G0 — Confirmar modo de operação

Contexto:
Leonardo quer transformar o Project Handoff em uma Skill standalone.
A Skill deve carregar o documento completo dentro da própria árvore.
O objetivo é começar do zero, avançar gate a gate e gerar outputs em uma conversa só.

Opção A — Standalone Skill + Document Factory
- Vantagem: não depende de upload externo nem busca manual.
- Risco: pacote maior e mais pesado.
- Quando escolher: quando a prioridade é continuidade e autonomia.

Opção B — Skill leve + referência externa
- Vantagem: menor pacote.
- Risco: volta ao problema de achar/referenciar documento.
- Quando escolher: só se houver repositório externo bem versionado.

Recomendação provisória:
Opção A. O documento canônico deve ficar dentro do pacote.

Leonardo responde:
A / B / editar / adiar

## Gates P1–P9

|Gate|Done Definition|
|---|---|
|G-001|Corpus relevante centralizado|
|G-002|Arquivos principais indexados|
|G-003|Timeline real reconstruída|
|G-004|Versões canônicas definidas|
|G-005|Portfólio com score|
|G-006|Top 3 MVP candidates definidos|
|G-007|Top 5 conteúdos publish-first definidos|
|G-008|1 teste público pronto ou em execução|
|G-009|Backlog de 7 dias definido|