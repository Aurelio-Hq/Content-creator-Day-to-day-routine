# PHASE MAP

|Phase|Name|Objective|Output|
|---|---|---|---|
|P0|Intake / Freeze|Congelar criação nova e instalar Discovery Vault|PROJECT_USER_MESSAGE.md, PROJECT_MANIFESTO.md|
|P1|Organização Digital / Discovery Vault|Centralizar arquivos no Discovery Vault|DISCOVERY_VAULT_OPERATING_SYSTEM.md|
|P2|Indexação|Transformar arquivos em base de dados|MASTER_INDEX.csv, ASSET_REGISTRY.csv, CORPUS_INDEXING_PROTOCOL.md|
|P3|Timeline / Evolução|Reconstruir evolução real do projeto|TIMELINE_DISCOVERY.md, DISCOVERY_EXIT_MAP.md|
|P4|Deduplicação / Canônicos|Separar versões atuais, duplicadas e superseded|CANONICAL_MAP.csv, SUPERSEDED_LIST.csv|
|P5|Score de Portfólio|Ranquear famílias de produto|PRODUCT_PORTFOLIO.csv, MVP_CANDIDATES.csv|
|P6|Decisão MVP|Escolher Top 3 candidatos a MVP|MVP_DECISION_MEMO.md|
|P7|Publication Pipeline|Escolher Top 5 conteúdos publish-first|CONTENT_INVENTORY.csv, PUBLICATION_QUEUE.md|
|P8|Validação Pública|Obter sinais reais de demanda externa|VALIDATION_REPORT.md|
|P9|Next Sprint|Backlog de 7 dias baseado em evidência|7_DAY_BACKLOG.md, CURRENT_PHASE_TRACKER.md|