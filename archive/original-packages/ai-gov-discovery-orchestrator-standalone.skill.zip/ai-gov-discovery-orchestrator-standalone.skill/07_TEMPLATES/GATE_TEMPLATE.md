# GATE P#.S#.G# — [Nome do gate]

## Contexto
[Resumo em até 5 linhas]

## Opção A — [nome]
- Vantagem:
- Risco:
- Quando escolher:

## Opção B — [nome]
- Vantagem:
- Risco:
- Quando escolher:

## Recomendação provisória
[A ou B, com justificativa curta]

## Leonardo responde
A / B / editar / adiar
