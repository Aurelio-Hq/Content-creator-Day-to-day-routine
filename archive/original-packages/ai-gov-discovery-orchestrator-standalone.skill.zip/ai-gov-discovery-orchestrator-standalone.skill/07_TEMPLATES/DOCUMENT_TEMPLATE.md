---
id: DOC-YYYYMMDD-###
title: ""
type: ""
status: Draft
owner: Leonardo
phase: P#
step: S#
created_at: 2026-05-22
tags: []
---

# Título

## 1. Objetivo
TBD

## 2. Contexto
TBD

## 3. Decisões relacionadas
TBD

## 4. Estrutura operacional
TBD

## 5. Gates
TBD

## 6. Done Definition
TBD

## 7. Próximas 3 tarefas
1. TBD
2. TBD
3. TBD
