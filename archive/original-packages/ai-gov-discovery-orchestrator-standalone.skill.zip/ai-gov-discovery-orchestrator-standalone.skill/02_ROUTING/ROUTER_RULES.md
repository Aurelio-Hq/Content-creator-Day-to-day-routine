# ROUTER RULES

## Core Instruction

This skill is standalone. Do not request the original Project Handoff document. Use the embedded canonical source.

## Trigger → Route

| Trigger | Route | Output |
|---|---|---|
| `/day-zero` | Gate Zero protocol | GATE P0.S0.G0 + tracker + next 3 tasks |
| `/gate-zero` | Gate Zero protocol | GATE P0.S0.G0 |
| `/next-3-tasks` | Tracker protocol | current phase + next tasks |
| `/decision-check D-###` | Decision registry | decision + contestability |
| `/build-doc DOC-###` | Document factory | document stub/final |
| `/score-portfolio` | Portfolio score | score table |
| `/export-package` | Export protocol | README + index + JSON/CSV |
| `/create-vault` | Vault script | folder structure command |

## Progressive Disclosure

Do not load the full JSON for simple tasks. Load the full JSON only for:

- full reconstruction
- export
- deep audit
- package regeneration
- resolving conflict between summaries

## Default Day Zero State

```yaml
CURRENT_PHASE: P0 — Intake / Freeze
CURRENT_STEP: S0 — Gate Zero
NEXT_GATE: GATE P0.S0.G0
NEXT_DOCUMENT: PROJECT_USER_MESSAGE.md
```
