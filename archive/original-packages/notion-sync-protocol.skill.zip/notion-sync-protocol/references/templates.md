# Templates de Pages — Por Tipo de Conteúdo

## Como usar este arquivo

Leia o template correspondente ao tipo de page sendo criada.
Copie a estrutura e preencha com os dados do usuário.
Todos os templates têm seções obrigatórias (★) e opcionais (○).

---

## Template 1 — Artigo Editorial (M1)

```
# [Emoji] [Título do Artigo]

★ 🎯 TESE CENTRAL (1 frase que o leitor consegue repetir depois de ler):
[frase aqui]

★ 📦 ENTREGÁVEL: Artigo publicado em [plataformas]
★ ✅ DONE DEFINITION: Publicado + link ativo + 1 formato alternativo gerado
★ 📅 DEADLINE: [data]

---

## A — Cross-Check Estratégico

[ ] Alinhado com eixo editorial: [eixo]
[ ] Relevante para AI Act / Posicionamento NL?
[ ] Nível de consciência do leitor: Iniciante / Médio / Avançado
[ ] Coesão com artigos anteriores?
Score de aderência: __/100

## B — Fonte Primária

Fonte: [título + link]
Data: [data da fonte]
Tipo: Lei / Guideline / Paper / Estudo / Case
Credibilidade: Alta / Média / Baixa
Notas da análise: [resumo da leitura]

## C — Outline

1. [Introdução / Problema]
2. [Desenvolvimento / Insight 1]
3. [Desenvolvimento / Insight 2]
4. [Implicação prática]
5. [Fechamento / Frase memorável]

## D — Draft

[Rascunho completo aqui]

## E — Safe-Check

[ ] Sem alucinações ou dados não verificados
[ ] Claims com base em fonte primária
[ ] Sem viés político/comercial detectado
[ ] Consistente com linha editorial
Resultado: Aprovado / Revisar → [lista de correções]

## F — Bench-Check

Busca realizada: [data]
Score de originalidade: ___%
Fontes concorrentes encontradas: [lista]
Diferenciação clara: Sim / Não → [ajuste necessário]

## G — Versão Final

[Texto final revisado]

## H — Formatos Derivados

○ LinkedIn Post: [texto adaptado — máx 1300 caracteres]
○ Carrossel (slides): [estrutura — 1 slide por ponto-chave]
○ Newsletter: [versão resumida — 200 palavras]
○ Thread Twitter/X: [5-7 tweets]
○ Versão NL (holandês): [se aplicável]

## I — Publicação

[ ] Publicado em: [plataforma 1] — [data] — [link]
[ ] Publicado em: [plataforma 2] — [data] — [link]
[ ] Notion atualizado — Status: Publicado
[ ] LinkedIn post feito
```

---

## Template 2 — Case de Portfolio (M2)

```
# [Emoji] [Nome do Projeto]

★ 🎯 OBJETIVO: [1 linha clara]
★ 📦 ENTREGÁVEL: [o que sai quando pronto]
★ ✅ DONE DEFINITION: [critério objetivo e mensurável]
★ 📅 DEADLINE: [data]
★ 🏢 CARGO-ALVO ALINHADO: [AI PM / AI Governance PM / ...]

---

## S1 — Scoping

Problema: [qual dor o projeto resolve?]
Solução proposta: [abordagem geral]
Stack tecnológico: [ferramentas e tecnologias]
Dependências: [o que precisa estar pronto antes?]
Score Fit Mercado NL: __/100

## S2 — Desenvolvimento

[Documentação do processo de desenvolvimento]
[Decisões técnicas tomadas e justificativas]
[Desafios encontrados]

## S3 — Revisão

[ ] Funciona conforme especificado?
[ ] Documentação completa?
[ ] Screenshot / diagrama de arquitetura criado?
[ ] Alinhado com Done Definition?
Gaps identificados: [lista]
Correções realizadas: [lista]

## S4 — Publicação e Distribuição

[ ] GitHub README criado — [link]
[ ] LinkedIn post publicado — [link]
[ ] Artigo/Case Study publicado — [link]
[ ] Notion atualizado — Status: Publicado

## Narrativa do Case (para LinkedIn/Medium)

Problema: [descrição para leigo]
Abordagem: [como foi resolvido]
Resultado: [impacto mensurável]
Stack: [tecnologias utilizadas]
Lições: [o que aprendeu]
```

---

## Template 3 — Estudo de Certificação (M3)

```
# [Emoji] [Nome da Certificação] — Study Sprint

★ 🎯 META: Score ≥80% em 2 simulados consecutivos
★ 📦 ENTREGÁVEL: Badge/cert + conteúdo derivado publicado
★ ✅ DONE DEFINITION: Score ≥80% consistente + exame agendado
★ 📅 DEADLINE DO EXAME: [data]
★ 💰 CUSTO: [USD]

---

## Sprint 1 — Fonte Primária

Fonte oficial: [link]
Domínios do exame: [lista com % de peso]
Horas estimadas de estudo: [n]h
Notas sistematizadas: [análise por domínio]

## Sprint 2 — Outline e Gaps

Domínios dominados: [lista]
Domínios com gap: [lista]
Recursos de nivelamento: [links]
Outline de artigo derivado: [estrutura]

## Sprint 3 — Simulados

| Simulado | Data | Score | Gaps Identificados |
|---|---|---|---|
| #1 | — | —% | — |
| #2 | — | —% | — |
| #3 | — | —% | — |

Gate: ≥80% em 2 simulados consecutivos → agendar exame

## Sprint 4 — Conteúdo Derivado

[ ] Artigo ou post LinkedIn criado sobre este domínio
[ ] Adicionado ao Calendário Editorial M1
Título sugerido: [título do conteúdo]

## Sprint 5 — Exame Real

Data agendado: [data]
Local/plataforma: [onde]
Resultado: Aprovado / Reprovado
Score final: ___%
Badge Credly: [link]
```

---

## Template 4 — Log Diário (M4)

```
# 📋 Log [Data — DD/MM/AAAA]

★ Macro do Dia: [M1 / M2 / M3 / M5 / M6 / Misto]

---

## AM — Briefing

Prioridade do dia: [1 item]
Tarefas planejadas:
  1. [tarefa] → [tempo estimado]
  2. [tarefa] → [tempo estimado]
  3. [tarefa] → [tempo estimado]
Entregável esperado: [o que deve estar pronto até 18h]
Milestone em risco hoje: [se houver]

## PM — Status

Entregável: Entregue / Parcial / Não feito / Bloqueado
O que foi feito: [descrição]
O que não foi feito: [descrição]
Bloqueio: [se houver]
Energia 1-5: [n]

KPIs físicos:
  Passos: [n] (meta: 15.000)
  Sono ontem: [n]h (meta: 7h)
  Refeições: [n] (meta: 3)

Notas livres: [observações do dia]
```

---

## Template 5 — Candidatura (M5)

```
# 🏢 [Empresa] — [Cargo]

★ Score Fit: __/100
★ Status: [Identificada / Aplicada / ...]
★ Deadline Follow-up: [Data Aplicação + 7 dias]

---

## Análise da Vaga

Cargo: [título exato]
Empresa: [nome + setor]
País: [Holanda / Portugal / ...]
Salário estimado: €[n]–[n]k/ano
Plataforma: [LinkedIn / Indeed NL / ...]

## Fit Analysis

Certs necessárias na vaga:
  [ ] [cert 1] — [tenho / em andamento / não tenho]
  [ ] [cert 2] — [tenho / em andamento / não tenho]

Gap de perfil: [o que falta para 100% de fit]
Pontos fortes para destacar: [lista]

## Documentos

[ ] CV adaptado: [link]
[ ] Carta de motivação: [link]
[ ] LinkedIn summary adaptado: [texto]

## Histórico

| Data | Ação | Resposta |
|---|---|---|
| [data aplicação] | Candidatura enviada | — |
| [data + 7d] | Follow-up enviado | — |
| — | — | — |

## Prep para Entrevista

Talking points principais:
  1. [ponto 1]
  2. [ponto 2]
  3. [ponto 3]

Perguntas para fazer ao entrevistador:
  1. [pergunta]
  2. [pergunta]
```
