# Workspace Map — Arquitetura Completa

## Master Dashboard

Page raiz: `🧠 SISTEMA MASTER 2026`

### Tabela de Status Geral (atualizar semanalmente)

| Macro | Sprint Ativa | Entregável Semana | Done Definition | Status |
|---|---|---|---|---|
| M1 Editorial | — | — | Artigo publicado ≥2 plataformas | — |
| M2 Portfolio | — | — | Case publicado + Notion atualizado | — |
| M3 Certs | — | — | Score ≥80% + exame agendado | — |
| M4 Agente | Contínua | Log diário preenchido | Email AM+PM + Notion atualizado | — |
| M5 Carreira | — | — | Candidatura enviada + follow-up | — |
| M6 Admin | — | — | Tarefa resolvida + evidência | — |

### Milestones Críticos

| Data | Milestone | Macro | Ação Imediata | Status |
|---|---|---|---|---|
| 11/04/2026 | Promo UiPath expira | M3 | Pagar voucher AGORA | Pendente |
| 17/04/2026 | AZ-104 muda conteúdo | M3 | Baixar novo study guide | Pendente |
| 30/06/2026 | AI-102 aposenta | M3 | Fazer exame antes desta data | Pendente |
| 01/06/2026 | Candidaturas ativas | M5 | Portfolio + LinkedIn prontos | Pendente |
| 01/08/2026 | Viagem Holanda | M6 | Marco definitivo do plano | Pendente |

---

## M1 — Editorial AI Anatomy

### Database: Calendário Editorial

Linha editorial ativa: AI Anatomy
Plataformas: Blog AI Anatomy | LinkedIn | Medium | Frankwatching NL

Eixos editoriais disponíveis como SELECT:
- Filosófica / Ética Responsável
- AI Literacy / AI Act (Iniciante → Avançado)
- AI at Work (dicas práticas por profissional/área)
- AI Anatomy — Erros, Alucinação, Falhas
- AI for Students

Status permitidos:
Ideia → Rascunho → Safe-Check → Bench-Check → Pronto → Publicado

Formatos permitidos:
Artigo Tese | Framework | Fricção | Ensaio Aplicado | Carrossel | Vídeo

### Database: Pipeline Frankwatching (9 artigos fixos)

Sequência de publicação planejada:
1. "AI literacy não é prompt training"
2. "Classifique tarefas antes de classificar ferramentas"
3. "Três controles mínimos para usar IA sem virar caos"
4. "Supervisão humana não é carimbo"
5. "Maturidade em IA começa quando a equipe faz perguntas melhores"
6. "O erro de confundir domínio de interface com capacidade de decisão"
7. "Por que política sem prática vira teatro de compliance"
8. "Quanto mais perto a IA do institucional, menos aceitável é improvisar"
9. "O maior risco da IA corporativa não é erro factual — é erro plausível"

---

## M2 — Portfolio & Projetos

### Database: Portfolio Cases

Projetos ativos:
- PORT-001: Domingos Case | Deadline 15/04/2026
- PORT-002: Portfolio 2 | Deadline 15/05/2026
- PORT-003: Portfolio 3 | Deadline a confirmar
- PROJ-AI-RISK: Integração dados AI Risk | Sem data
- PROJ-LITERACY: AI Agent Literacy Act | Sem data
- PROJ-FRAMEWORK: Framework Governance | Sem data
- PROJ-000: Agente IA Próprio | Em desenvolvimento

Fases de sprint padrão:
S1 Scoping → S2 Dev → S3 Revisão → S4 Publicado

Cargos-alvo para alinhamento (multi-select):
AI PM | AI Governance PM | Responsible AI Lead | AI Risk Lead | Cloud Engineer

---

## M3 — Certificações

### Database: Tracker Certificações

20 certificações ativas. Ver field-schemas.md para propriedades.

Grupos por urgência:
- 🔴 URGENTE: Prompt Eng Anthropic, Prompt Eng GPT, N8N L1+L2,
  UiPath Agentic AA (promo 11/04), AI-102 (aposenta 30/06)
- 🟡 ALTA: AZ-900, AZ-104, PSPO-AI, AIGP, EXIN AICP,
  ISO 42001 LI, IELTS, Holandês NT2-I
- 🟢 MÉDIA: IBM AI Developer, IBM AI Engineering,
  AI-900, N8N Udemy, UiPath Developer AA, UiPath SAI

Gate de aprovação universal: Score ≥80% em 2 simulados consecutivos

---

## M4 — Agente Diário

### Database: Log Diário

Registro diário obrigatório. Uma entrada por dia.
Criar entrada AM ao gerar briefing.
Atualizar entrada PM ao processar status noturno.

Templates:
- Template AM: `/M4 Agente Diário/📧 Template AM`
- Template PM: `/M4 Agente Diário/📧 Template PM`

---

## M5 — Carreira CRM

### Database: Pipeline Candidaturas

Gate de ativação: 01/06/2026
Mercados-alvo: Holanda | Portugal | Bélgica | Remoto UE

Status do pipeline:
Identificada → Aplicada → Follow-up Enviado →
Entrevista → Oferta → Rejeitada | Inativa

### Database: Networking

Contatos prioritários ativos:
- Kim de Klerk (Krachtig NL) — status: Frio

---

## M6 — Admin & Financeiro

### Database: Pendências Admin

Pendências críticas ativas:
- CPF/DRI Itaú | Deadline 31/03 | Bloqueia: Nenhum
- CNH + Receita Federal | Deadline 03/04 | Bloqueia: Nenhum
- Pendências Vera Brasil | Deadline 10/04 | Bloqueia: Nenhum
- Passagem Holanda | Deadline 30/04 | Bloqueia: M6 Viagem
- Abertura PJ DRI Brasil | Deadline 01/05 | Bloqueia: Negócios

### Database: Orçamento Certs

Meta total: $6.000–8.000 USD
Mínimo possível: $4.500
Máximo sem controle: $17.700

Estratégia de redução:
- Priorizar versões e-learning sobre presencial
- Usar promos ativos (UiPath UIAAA50OFF2026)
- MS Learn gratuito para AZ-900, AZ-104 prep
- IAPP BoK gratuito para AIGP prep
