# Field Schemas — Propriedades Obrigatórias por Database

## Regra Geral

Campos marcados com ★ são OBRIGATÓRIOS em toda criação.
Campos marcados com ○ são opcionais mas recomendados.
Nunca criar registro sem os campos ★.

---

## M1 — Calendário Editorial

### Propriedades obrigatórias ★

| Campo | Tipo | Valores Permitidos |
|---|---|---|
| ★ Título do Artigo | text | Nome claro, máx 8 palavras |
| ★ Eixo Editorial | select | Filosófica/Ética \| AI Literacy/AI Act \| AI at Work \| AI Anatomy Erros \| AI for Students |
| ★ Plataforma | multi-select | Frankwatching NL \| Medium \| LinkedIn \| Blog AI Anatomy \| Carrossel |
| ★ Status | select | Ideia \| Rascunho \| Safe-Check \| Bench-Check \| Pronto \| Publicado |
| ★ Formato | select | Artigo Tese \| Framework \| Fricção \| Ensaio Aplicado \| Carrossel \| Vídeo |
| ○ Deadline | date | — |
| ○ Keywords SEO | text | Mínimo 3 keywords |
| ○ Score Originalidade % | number | 0–100 |
| ○ Língua | select | PT \| EN \| NL |

---

## M2 — Portfolio Cases

### Propriedades obrigatórias ★

| Campo | Tipo | Valores Permitidos |
|---|---|---|
| ★ Nome do Projeto | text | Máx 6 palavras |
| ★ Tipo | select | Case Study \| AI Agent \| Framework \| Análise \| Integração |
| ★ Fase Atual | select | S1 Scoping \| S2 Dev \| S3 Revisão \| S4 Publicado |
| ★ Done Definition | text | Critério objetivo e mensurável |
| ★ Status | select | Pendente \| Em andamento \| Publicado \| Pausado |
| ○ Deadline | date | — |
| ○ Cargo-Alvo Alinhado | multi-select | AI PM \| AI Governance PM \| Responsible AI Lead \| AI Risk Lead |
| ○ Score Fit Mercado NL | number | 0–100 |
| ○ Plataformas Publicação | multi-select | LinkedIn \| GitHub \| Medium \| Blog |
| ○ GitHub URL | url | — |

---

## M3 — Tracker Certificações

### Propriedades obrigatórias ★

| Campo | Tipo | Valores Permitidos |
|---|---|---|
| ★ Certificação | text | Nome oficial completo |
| ★ Provedor | text | Ex: Microsoft, IAPP, EXIN |
| ★ Prioridade | select | 🔴 Urgente \| Alta \| Média \| Baixa |
| ★ Status | select | Não Iniciado \| Estudando \| Quiz Mode \| Exame Agendado \| Aprovado \| Adiado |
| ★ Gate Aprovação | number | Sempre 80 (score mínimo) |
| ○ Custo USD | number | — |
| ○ Deadline | date | — |
| ○ Horas Estudo Est. | number | — |
| ○ Score Simulado 1 | number | 0–100 |
| ○ Score Simulado 2 | number | 0–100 |
| ○ Score Simulado 3 | number | 0–100 |
| ○ Validade Cert | text | Ex: 1 ano, 3 anos, Vitalícia |
| ○ Conteúdo Gerado | checkbox | Virou artigo/post? |

### Lógica de atualização de score

Ao atualizar Score Simulado N:
1. Verificar se score ≥ 80
2. Se sim E score anterior também ≥ 80:
   → Sugerir agendar exame real
   → Atualizar Status para "Exame Agendado"
3. Se não:
   → Identificar domínios com gap
   → Sugerir revisão direcionada

---

## M4 — Log Diário

### Propriedades obrigatórias ★

| Campo | Tipo | Notas |
|---|---|---|
| ★ Data | date | Data do dia (não datetime) |
| ★ Macro do Dia | select | M1 \| M2 \| M3 \| M5 \| M6 \| Misto |
| ★ Status PM | select | Entregue \| Parcial \| Não feito \| Bloqueado |
| ★ Energia 1-5 | number | 1 = exausto, 5 = ótimo |
| ○ Prioridade AM | text | O que foi planejado pela manhã |
| ○ Entregável do Dia | text | O que foi produzido de fato |
| ○ Bloqueio | text | O que impediu progresso |
| ○ Passos | number | Meta: 15.000/dia |
| ○ Sono horas | number | Meta: 7h/noite |
| ○ Notas | text | Observações livres |

### Regra de criação do log diário

- Criar entrada AM ao gerar briefing matinal
- Atualizar entrada PM ao processar email de status
- Uma entrada por dia — nunca criar duplicata na mesma data
- Se já existe entrada do dia → atualizar, não criar nova

---

## M5 — CRM Candidaturas

### Propriedades obrigatórias ★

| Campo | Tipo | Valores Permitidos |
|---|---|---|
| ★ Empresa | text | — |
| ★ Cargo | text | Nome exato da vaga |
| ★ País | select | Holanda \| Portugal \| Bélgica \| Remoto UE |
| ★ Status | select | Identificada \| Aplicada \| Follow-up Enviado \| Entrevista \| Oferta \| Rejeitada \| Inativa |
| ★ Plataforma | select | LinkedIn \| Indeed NL \| Glassdoor \| Direta |
| ○ Score Fit % | number | 0–100 |
| ○ Data Aplicação | date | — |
| ○ Follow-up Data | date | Sempre D+7 da aplicação |
| ○ Certs Necessárias | multi-select | — |
| ○ Gap de Perfil | text | O que falta para qualificar 100% |
| ○ Contato Recrutador | text | Nome + email/LinkedIn |

### Lógica automática pós-candidatura

Quando Status muda para "Aplicada":
→ Calcular Follow-up Data = Data Aplicação + 7 dias
→ Sugerir criar evento no Google Calendar para o follow-up

---

## M5 — Networking

### Propriedades obrigatórias ★

| Campo | Tipo | Valores Permitidos |
|---|---|---|
| ★ Nome | text | — |
| ★ Status Relação | select | Frio \| Morno \| Quente \| Parceiro |
| ○ Empresa | text | — |
| ○ Papel | text | Ex: Recruiter, PM, Researcher |
| ○ País | select | Holanda \| Portugal \| Bélgica \| Remoto |
| ○ Último Contato | date | — |
| ○ Próxima Ação | text | Ex: Follow-up artigo, Proposta parceria |

---

## M6 — Pendências Admin

### Propriedades obrigatórias ★

| Campo | Tipo | Valores Permitidos |
|---|---|---|
| ★ Tarefa | text | Máx 6 palavras |
| ★ Categoria | select | Legal \| Financeiro \| Viagem \| Docs Brasil \| Saúde |
| ★ Status | select | Pendente \| Em Andamento \| Resolvido \| Bloqueado |
| ○ Deadline | date | — |
| ○ Bloqueia Macro | select | M1 \| M2 \| M3 \| M4 \| M5 \| M6 \| Nenhum |
| ○ Evidência | text | Link, número de protocolo, comprovante |

---

## M6 — Orçamento Certs

### Propriedades obrigatórias ★

| Campo | Tipo | Notas |
|---|---|---|
| ★ Item | text | Nome da cert/curso |
| ★ Custo Mín USD | number | — |
| ★ Custo Máx USD | number | — |
| ★ Pago? | checkbox | — |
| ○ Data Pagamento | date | — |
| ○ Estratégia Redução | text | Como economizar neste item |
| ○ Quando Pagar | text | Ex: Agora, Abril, Junho |
