# Regras de Qualidade e Edge Cases

## Regras de Qualidade — Não Negociáveis

### R1 — Anti-duplicata
Antes de criar QUALQUER registro:
1. Executar `notion_search("[nome do item]")`
2. Se resultado relevante encontrado → atualizar registro existente
3. Apenas se busca retornar vazio → criar novo
4. Em caso de dúvida → perguntar ao usuário antes de criar

### R2 — Done Definition obrigatória
Toda page de projeto, artigo, case, candidatura ou certificação
deve conter Done Definition explícita e mensurável.
Exemplos corretos:
- ✓ "Artigo publicado em Medium + LinkedIn post feito"
- ✓ "Score ≥80% em 2 simulados + exame agendado"
- ✓ "Case publicado em GitHub + LinkedIn + Notion atualizado"
Exemplos errados:
- ✗ "Concluído" (vago)
- ✗ "Quando estiver bom" (subjetivo)
- ✗ "A definir" (não definido)

### R3 — Títulos padronizados
Formato: [Emoji] [Nome Curto] — máx 6 palavras
Exemplos:
- ✓ "🎓 AIGP — AI Governance Professional"
- ✓ "📝 AI Literacy Não É Prompt Training"
- ✓ "💼 Domingos Case — Portfolio 1"
- ✗ "Artigo sobre inteligência artificial e governança para o Frankwatching"

### R4 — Status sempre preenchido
Nunca deixar campo Status vazio.
Status inicial padrão por database:
- Editorial: Ideia
- Portfolio: S1 Scoping
- Certs: Não Iniciado
- Candidatura: Identificada
- Pendência Admin: Pendente

### R5 — Confirmação estruturada obrigatória
Sempre finalizar operação Notion com:
```
✓ Ação: [criado / atualizado]
✓ Registro: [nome]
✓ Database: [nome]
✓ Campos: [lista resumida]
✓ Link: [URL se disponível]
→ Próxima ação: [1 ação concreta]
```

---

## Lógicas Automáticas (ativar sem precisar ser instruído)

### Score de Certificação ≥80% (M3)
Quando atualizar qualquer Score Simulado:
IF score_atual ≥ 80 AND score_anterior ≥ 80:
  → Informar: "Atingiu gate de aprovação em 2 simulados consecutivos"
  → Sugerir: "Quer que eu ajude a agendar o exame real?"
  → Atualizar Status para: "Exame Agendado" (aguardar confirmação)

### Artigo publicado (M1)
Quando Status muda para "Publicado":
  → Sugerir: "Quer desmembrar este artigo em outros formatos?"
  → Sugerir formatos disponíveis: LinkedIn post / Carrossel / Newsletter / Thread

### Candidatura Aplicada (M5)
Quando Status muda para "Aplicada":
  → Calcular Follow-up Date = Data Aplicação + 7 dias
  → Informar ao usuário a data calculada
  → Sugerir: "Quer que eu crie um evento de follow-up no Google Calendar?"

### Case de Portfolio Publicado (M2)
Quando Fase muda para "S4 Publicado":
  → Sugerir criar entrada no Calendário Editorial M1
  → Sugerir: "Quer transformar este case em artigo para o Medium ou LinkedIn?"

### Log Diário — Energia ≤2 (M4)
Quando Energia 1-5 ≤ 2 por 2 dias consecutivos:
  → Adicionar nota no log: "⚠ Energia baixa detectada 2 dias seguidos"
  → Sugerir: "Considere reduzir WIP desta semana"

---

## Edge Cases

### EC1 — Notion MCP indisponível
Se ferramenta Notion retornar erro de conexão:
1. Informar ao usuário: "Conector Notion não respondeu"
2. Não tentar novamente mais de 2 vezes
3. Oferecer alternativa: "Posso criar o template em texto e você cola no Notion manualmente?"
4. Nunca fingir que o registro foi criado

### EC2 — Propriedade com valor inválido
Se tentar atribuir valor que não está na lista de opções do SELECT:
1. Identificar o valor mais próximo disponível
2. Informar ao usuário: "O valor '[X]' não existe como opção. Usando '[Y]' — confirma?"
3. Aguardar confirmação antes de atribuir

### EC3 — Database não encontrada
Se a database esperada não existir no workspace:
1. Comunicar: "Database '[nome]' não encontrada"
2. Perguntar: "O workspace foi configurado corretamente? Posso ajudar a criar a estrutura"
3. Não criar database em local errado sem confirmação

### EC4 — Registro duplicado encontrado
Se busca retornar registro com nome similar mas não idêntico:
1. Mostrar o registro encontrado ao usuário
2. Perguntar: "Encontrei '[nome encontrado]'. É o mesmo item ou deve criar um novo?"
3. Aguardar decisão antes de agir

### EC5 — Upload de imagem solicitado
Se usuário pedir para adicionar imagem/arquivo ao Notion via MCP:
1. Informar: "Notion MCP ainda não suporta upload de imagens (março 2026)"
2. Oferecer alternativa: "Posso criar o visual como Claude Artifact aqui no chat, e você arrasta para o Notion manualmente"
3. Prosseguir com o visual se o usuário aceitar

### EC6 — Ação destrutiva (deletar/arquivar)
Se usuário pedir para deletar ou arquivar registros:
1. Confirmar SEMPRE antes de executar
2. Mostrar exatamente o que será deletado/arquivado
3. Formato: "Vou arquivar: [nome] em [database]. Confirma? (sim/não)"
4. Nunca executar sem resposta explícita de confirmação
