---
name: notion-sync-protocol
description: >
  Protocolo mestre de criação, leitura, atualização e sincronização
  no Notion workspace do usuário via conector MCP. Ative SEMPRE que
  o usuário mencionar: "salva no Notion", "atualiza o dashboard",
  "cria uma page", "registra no tracker", "coloca no Notion",
  "anota no calendário editorial", "atualiza o CRM", "log do dia",
  "registra o score", "cria o case", "adiciona à pendência",
  ou qualquer variação de registrar, salvar, documentar, criar,
  atualizar, ou organizar algo dentro do Notion.
  Também ativa AUTOMATICAMENTE ao final de qualquer macro executado
  (M1 Editorial, M2 Portfolio, M3 Certs, M4 Agente Diário,
  M5 Carreira, M6 Admin) para sincronizar o entregável produzido.
  Nunca pergunte se deve salvar no Notion após executar um macro —
  simplesmente execute a sincronização e confirme ao usuário.
version: "1.0.0"
author: Leonardo — Sistema 2026
compatibility: claude.ai, Claude Desktop
requires: Notion MCP connector ativo (https://mcp.notion.com/mcp)
---

# NOTION SYNC PROTOCOL
## Skill de Sincronização Master — Sistema 2026

---

## Seção 0 — Leia Primeiro

Esta skill opera sobre um workspace Notion com arquitetura fixa
de 6 macros. Antes de qualquer ação, identifique:
1. Qual macro originou a ação?
2. Qual database é o destino?
3. Criar novo registro ou atualizar existente?

Para detalhes completos de cada macro, leia os arquivos de referência:
- `references/workspace-map.md` → arquitetura completa + databases
- `references/field-schemas.md` → propriedades obrigatórias por database
- `references/templates.md` → templates de pages por tipo de conteúdo
- `references/rules.md` → regras de qualidade e edge cases

---

## Seção 1 — Protocolo de Execução (5 passos)

### PASSO 1 — IDENTIFICAR DESTINO

```
MACRO ORIGEM → DATABASE DESTINO → AÇÃO
───────────────────────────────────────
M1 Editorial  → Calendário Editorial OU Pipeline Frankwatching
M2 Portfolio  → Portfolio Cases OU Sprint Log
M3 Certs      → Tracker Certificações (atualizar score/status)
M4 Agente     → Log Diário (criar entrada do dia)
M5 Carreira   → CRM Candidaturas OU Networking
M6 Admin      → Pendências Admin OU Orçamento Certs
```

Se ambíguo → perguntar qual database antes de agir.
Nunca criar na page errada.

### PASSO 2 — VERIFICAR DUPLICATA

Antes de criar qualquer page ou registro:
1. Buscar no Notion: nome similar já existe?
2. Se existe → ATUALIZAR (não duplicar)
3. Se não existe → CRIAR novo

Comando de busca: `notion_search("nome do item")`
Se retornar resultado relevante → usar o ID existente.

### PASSO 3 — EXECUTAR A AÇÃO

**Para CREATE (novo registro):**
→ Usar propriedades mínimas obrigatórias do schema
→ Ver `references/field-schemas.md` para cada database
→ Sempre incluir: título, status inicial, deadline (se aplicável)
→ Sempre incluir: Done Definition em pages de projeto

**Para UPDATE (registro existente):**
→ Alterar apenas os campos relevantes
→ Não sobrescrever campos que o usuário não mencionou
→ Registrar data da atualização em campo "Última Atualização"

**Para PAGE COMPLETA (artigo, case, sprint):**
→ Usar template correspondente de `references/templates.md`
→ Preencher todas as seções do template
→ Linkar à database-mãe via propriedade de relação

### PASSO 4 — SINCRONIZAR DOWNSTREAM

Após criar/atualizar, verificar se há sincronizações encadeadas:

| Ação realizada | Sincronização downstream |
|---|---|
| Novo artigo criado (M1) | → Atualizar Dashboard M1 (contagem) |
| Score de cert atualizado (M3) | → Verificar se atingiu gate ≥80% → sugerir agendar exame |
| Case publicado (M2) | → Criar rascunho de post LinkedIn no M1 |
| Log diário criado (M4) | → Atualizar streak de KPIs no Master Dashboard |
| Candidatura aplicada (M5) | → Criar evento de follow-up no Google Calendar |
| Pendência resolvida (M6) | → Atualizar status no Master Dashboard |

### PASSO 5 — CONFIRMAR AO USUÁRIO

Sempre finalizar com confirmação estruturada:

```
✓ Criado/Atualizado: [nome do registro]
✓ Database: [nome da database]
✓ Campos preenchidos: [lista dos campos]
✓ Link: [URL da page se disponível]
→ Próxima ação sugerida: [1 ação concreta]
```

---

## Seção 2 — Mapa Rápido do Workspace

```
🧠 SISTEMA MASTER 2026
├── M1 Editorial AI Anatomy
│   ├── 📅 Calendário Editorial (database)
│   └── 🇳🇱 Pipeline Frankwatching (database — 9 artigos)
├── M2 Portfolio & Projetos
│   └── 💼 Portfolio Cases (database — 5 projetos)
├── M3 Certificações
│   └── 🎓 Tracker Certs (database — 20 certs)
├── M4 Agente Diário
│   ├── 📋 Log Diário (database)
│   ├── 📧 Template AM (page)
│   └── 📧 Template PM (page)
├── M5 Carreira CRM
│   ├── 🏢 Pipeline Candidaturas (database)
│   └── 🤝 Networking (database)
└── M6 Admin & Financeiro
    ├── ⚖️ Pendências Admin (database)
    └── 💰 Orçamento Certs (database)
```

Para schemas completos de cada database → `references/field-schemas.md`
Para templates de pages → `references/templates.md`

---

## Seção 3 — Regras Críticas

1. **Nunca duplicar** — buscar antes de criar
2. **Nunca deixar Done Definition vazio** em pages de projeto
3. **Sempre usar ícone emoji** como prefixo em títulos
4. **Títulos curtos** — máximo 6 palavras
5. **Status sempre preenchido** — nunca vazio
6. **Após score de cert**: perguntar se quer gerar quiz agora
7. **Após artigo publicado**: perguntar se quer desmembrar em formatos

---

## Seção 4 — Limitações Conhecidas (Março 2026)

| Limitação | Workaround |
|---|---|
| Upload de imagens/arquivos não suportado via MCP | Descrever visualmente ou usar Claude Artifacts |
| OAuth obrigatório — não headless | Requer sessão ativa do usuário |
| Tabelas inline complexas podem não renderizar | Usar propriedades de database |
| Relações entre databases requerem IDs exatos | Buscar ID antes de criar relação |
