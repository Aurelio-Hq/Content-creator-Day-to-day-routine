# Output schemas and controlled vocabulary

Read this at export time, or whenever the user wants a master index or a standardized table for XLS / Notion / Obsidian.

## Minimum viable master index

The lightest structure that still supports decisions. Start here before any heavier data tooling (L3+).

| ID | Source | Date | Concept | Type | Claim | Evidence | Metric | Risk | Status | Tags | Next Action |
|---|---|---|---|---|---|---|---|---|---|---|---|

## Default output schema

Use unless the user asks for something else.

| ID | Chat Name | Type | Frame | Question | Output | Data/Metric | Owner | Priority | Status | Tags |
|---|---|---|---|---|---|---|---|---|---|---|

## Controlled vocabulary

Keep these closed so exports stay sortable and filterable across tools.

- **Status:** Draft · Active · Validating · Decision · Archived
- **Type:** Idea · Thesis · Plan · Analysis · Decision · Task
- **Tags:** #strategy · #market · #problem · #customer · #jtbd · #finance · #growth · #ops · #risk · #validation · #execution · #data · #ai · #product · #workflow · #project
