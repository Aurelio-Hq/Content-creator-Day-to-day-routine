# Example invocation

A complete, well-formed Big Query input. Use it as the shape to coach the user toward when their input is thinner than this.

```text
/opus-reasoning-max-fak

BIG QUERY — BQ-001

Parent Question:
How can I validate whether macro personalization of AI accounts for non-devs
increases performance, reduces rework, and improves confidence at work?

Context:
I have a large personal corpus, many exported conversations, intense production
across two months, and risk of recreating what already exists.

Central Hypothesis:
A macro-personalized AI account with persistent decisions, workflows, skills,
and deterministic commands produces higher quality and less rework than generic
chat usage.

Internal Data Available:
Exported conversations, numerical variables, decisions, artifacts, scripts,
skills, outputs, recurring themes, timestamps, evidence of duplicated work.

External Data Required:
AI productivity benchmarks, AI adoption at work, rework-cost research, workflow
automation evidence, AI literacy evidence.

Subquestions:
1. Which internal signals indicate productivity gain or loss?
2. Which patterns show rework or recreation?
3. Which hypotheses can be validated only with my corpus?
4. Which hypotheses require external sources?
5. What minimum 7-day experiment proves value?

Expected Output:
Hypothesis -> Evidence -> Proxy -> Experiment matrix.

Decision Criterion:
If internal evidence shows recurrence, rework, and credible gain potential,
advance to a validation experiment.
```
