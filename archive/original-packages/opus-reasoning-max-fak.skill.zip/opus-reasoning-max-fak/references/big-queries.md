# Big Queries — template and type catalog

Read this when the user submits or asks to structure a Big Query. The session budget and the six-block answer format live in SKILL.md; this file holds the input template and the type catalog.

## Input template

```text
BIG QUERY — BQ-###

Parent Question:
[one central question]

Context:
[what problem is being investigated]

Central Hypothesis:
[what thesis is at stake]

Internal Data Available:
[what corpus data may help]

External Data Required:
[what benchmarks, sources, or market evidence are missing]

Subquestions:
1. [critical subquestion]
2. [critical subquestion]
3. [critical subquestion]
4. [optional]
5. [optional]

Expected Output:
[table, matrix, executive synthesis, roadmap, scorecard, or decision]

Decision Criterion:
[what must appear to advance, pause, kill, split, or validate]
```

## Type catalog

Tag each Big Query so the analysis emphasis is right — a BQ-MARKET that pretends to be a BQ-VALIDATION will skip the demand signal it most needs.

| Type | Use |
|---|---|
| BQ-STRATEGY | Strategic decision. |
| BQ-VALIDATION | Hypothesis validation. |
| BQ-DATA | Internal corpus or database analysis. |
| BQ-PRODUCT | Product, course, consulting, or skill. |
| BQ-MARKET | Market, ICP, demand, willingness to pay. |
| BQ-OPS | Execution, workflow, process, documentation. |
| BQ-RISK | Logical, technical, regulatory, or commercial risk. |
