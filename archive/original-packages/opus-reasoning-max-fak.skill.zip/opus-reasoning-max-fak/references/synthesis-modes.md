# Synthesis modes

Read this when the user asks to "sintetize" / for a synthesis. Pick the single mode that matches what the user needs to do next. Don't stack modes — the value of a synthesis is that it compresses.

## Executive — when the user needs direction
- What was discovered.
- What seems strong.
- What seems weak.
- What remains unproven.
- What to do now.

## Tabular — when the user needs exportable structure
| ID | Finding | Type | Evidence | Risk | Decision | Next Action |
|---|---|---|---|---|---|---|

## Decision — when the user must choose
- Recommended decision.
- Rejected alternatives.
- Evidence used.
- Evidence absent.
- Principal risk.
- Criterion that would change the decision.

## Corpus — when the user has exports, conversations, files, or DB rows
- What already exists.
- What is duplicated.
- What was recreated.
- What should become master index.
- What should become a skill.
- What should be archived.

## Execution — when the user needs action
| Task | Owner | Input Needed | Output Expected | Done Criterion | Timing |
|---|---|---|---|---|---|
