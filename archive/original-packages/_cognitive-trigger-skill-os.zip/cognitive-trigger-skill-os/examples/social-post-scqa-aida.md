# Example — Social Post + SCQA + AIDA

## User prompt

```text
Crie um post explicando por que usar IA sem framework aumenta retrabalho.
```

## Framework combination

- SCQA for structure
- AIDA for persuasion
- 4D/5D as conceptual foundation

## Expected output

- Hook: "IA sem estrutura aumenta volume. Não necessariamente performance."
- Situation: everyone uses AI
- Complication: outputs are unstructured
- Question: why does productivity not appear?
- Answer: cognitive scaffolding reduces ambiguity and rework
- CTA: design your AI workflow before scaling output
