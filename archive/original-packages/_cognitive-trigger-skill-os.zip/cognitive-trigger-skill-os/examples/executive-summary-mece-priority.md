# Example — Executive Summary + MECE + Prioritization

## User prompt

```text
Analise esse problema de retrabalho no meu processo de conteúdo e me dê um resumo executivo com prioridades.
```

## Framework combination

- 3P — Problem, Process, Progress
- MECE
- Theory of Constraints
- Eisenhower / impact-effort prioritization

## Expected output

| Section | Content |
|---|---|
| Executive thesis | The main source of rework is unclear decision criteria before production |
| MECE map | Briefing, production, review, approval, publishing |
| Constraint | Approval criteria arrive too late |
| Priorities | Fix briefing template, define review gate, standardize final checklist |
| Next action | Create one-page content briefing template |
