# Cognitive Trigger Skill OS

A Claude Skill repository for **framework-combination routing**: a non-dev user writes natural language such as “pesquisa”, “decisão”, “comunicação”, “planejamento”, or “resumo executivo”, and Claude applies the minimum viable combination of frameworks needed to produce a clear, auditable, and executable output.

## Core thesis

```text
Anthropic 4D AI Fluency
+ Leonardo 5D Operational Matrix
+ A-Z Framework Combination Router
+ Progressive Disclosure
+ Quality Bar
= clearer outputs
→ less ambiguity
→ less cognitive rework
→ better operational performance
```

## What this repo contains

```text
.claude/skills/cognitive-framework-router/SKILL.md
references/
  4d-5d-quality-bar.md
  az-framework-catalog.md
  routing-rules.md
  output-contracts.md
templates/
  pre-balance-questionnaire.md
  working-backwards-brief.md
  response-blueprints.md
examples/
  executive-summary-mece-priority.md
  social-post-scqa-aida.md
evals/
  eval_cases.json
  eval_cases.yaml
  rubric.json
scripts/
  framework_router.py
  run_evals.py
tests/
  test_framework_router.py
  test_eval_cases.py
docs/
  architecture.md
  dependency-map.md
  user-stories.md
  eval-guide.md
```

## Install as a Claude Code skill

Copy or symlink the skill folder into your Claude skills directory:

```bash
mkdir -p ~/.claude/skills
cp -R .claude/skills/cognitive-framework-router ~/.claude/skills/
```

Invoke explicitly:

```text
/cognitive-framework-router
```

Or use natural language triggers such as:

```text
Faça uma pesquisa sobre IA em educação e devolva um resumo executivo.
Preciso decidir entre duas estratégias de conteúdo.
Transforme esse diagnóstico em plano de ação.
Crie uma comunicação executiva para minha equipe.
```

## Run local tests

```bash
python -m unittest discover -s tests
python scripts/run_evals.py
```

## Design decisions

- The skill **does not choose one framework**. It chooses the smallest useful combination of frameworks.
- It uses a **pre-balance questionnaire** only when essential context is missing.
- It applies **working backwards** before execution-heavy outputs.
- It enforces a **minimum viable quality bar**: response length, format, evidence, risk, and next action must match the user’s situation.
- It keeps the SKILL.md lean; detailed catalogs live in `references/`.
