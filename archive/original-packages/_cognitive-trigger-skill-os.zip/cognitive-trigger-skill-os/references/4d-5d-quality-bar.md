# 4D + 5D Quality Bar

## Anthropic 4D AI Fluency

| D | Competency | Operational question | Skill function |
|---|---|---|---|
| D1 | Delegation | Should AI act here, and in what role? | Scope and role control |
| D2 | Description | Is the goal described clearly enough? | Input clarity |
| D3 | Discernment | Is the output useful, accurate, and sufficient? | Critical evaluation |
| D4 | Diligence | What responsibility remains with the human? | Governance and review |

## Leonardo 5D Operational Matrix

| D | Layer | Function | Guiding question | Output |
|---|---|---|---|---|
| D1 | Define | Define objective, scope, and success | What needs to be solved? | Clear mission |
| D2 | Dor | Identify pain, friction, rework, ambiguity | What loss or pain exists now? | Diagnostic anchor |
| D3 | Design | Choose cognitive structure | Which framework combination fits? | Method route |
| D4 | Data-driven | Anchor in data, evidence, metrics | What proves, measures, or invalidates this? | Auditable output |
| D5 | Delivery | Convert reasoning into artifact | What should the final artifact/action be? | Executable delivery |

## Causal sequence

```text
Delegation
→ Define
→ Dor
→ Design
→ Data-driven
→ Framework combination
→ Discernment
→ Delivery
→ Diligence
```

## Failure modes

| Missing layer | Likely failure |
|---|---|
| Delegation | AI works on the wrong task |
| Define | Output is generic |
| Dor | Solution does not address the real pain |
| Design | Answer is unstructured |
| Data-driven | Output is hard to validate |
| Framework routing | User must reorganize manually |
| Discernment | Weak output is accepted |
| Delivery | Analysis does not become action |
| Diligence | Risk is transferred silently to the user |
