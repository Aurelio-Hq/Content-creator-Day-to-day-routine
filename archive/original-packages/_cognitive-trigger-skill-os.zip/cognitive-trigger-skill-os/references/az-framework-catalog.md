# A-Z Framework Catalog

| Letter | Framework / Pattern | Primary use | Expected result |
|---|---|---|---|
| A | AIDA | Communication, copy, pitch | Attention → Interest → Desire → Action |
| B | Balanced Scorecard | Strategy and management | Objectives connected to indicators |
| C | Cynefin | Decision under uncertainty | Separate clear/complicated/complex/chaotic contexts |
| D | Double Diamond | Solution design | Diverge, understand, converge, solve |
| E | Eisenhower Matrix | Operational prioritization | Urgent / important / delegate / delete |
| F | First Principles | Deep analysis | Break assumptions into fundamentals |
| G | GROW | Coaching and leadership | Goal, Reality, Options, Way Forward |
| H | Hoshin Kanri | Strategic deployment | Connect vision, goals, initiatives, execution |
| I | Ishikawa / Fishbone | Root-cause diagnosis | Map causes before solution |
| J | Jobs to Be Done | Customer, product, value proposition | Understand desired progress |
| K | Kano Model | Product experience | Classify basic, performance, delight features |
| L | Lean Canvas | Business validation | Synthesize problem, solution, channels, revenue |
| M | MECE | Structured analysis | No overlap, no gaps |
| N | North Star Metric | Product and growth | Define central value metric |
| O | OKR | Strategic execution | Objective + measurable key results |
| P | 3P — Problem, Process, Progress | Operational diagnosis | Separate problem, process, desired progress |
| Q | QFD | Voice of customer to requirements | Translate needs into specifications |
| R | RACI | Roles and responsibility | Responsible, accountable, consulted, informed |
| S | SCQA | Executive communication | Situation, complication, question, answer |
| T | Theory of Constraints | Operational bottlenecks | Identify limiting constraint |
| U | User Story Mapping | Product, service, journey | Organize usage by value flow |
| V | Value Stream Mapping | Process and rework | Visualize waste, delay, bottleneck |
| W | 5W2H | Practical action plan | What, why, who, when, where, how, how much |
| X | X-Matrix | Strategy execution alignment | Connect goals, initiatives, metrics, owners |
| Y | Yamazumi Chart | Capacity and workload | Balance work across stages/people |
| Z | Zachman Framework | Enterprise/system architecture | Classify system by perspective and dimension |

## Proprietary caution

3P — Problem, Process, Progress is an internal operational lens. Present it as an internal applied framework, not as a universal external standard.
