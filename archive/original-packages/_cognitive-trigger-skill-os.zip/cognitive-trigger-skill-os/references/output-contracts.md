# Output Contracts

## Executive summary contract

Must include:
- core thesis
- framework combination
- decision logic
- risks / assumptions
- next action

## Research synthesis contract

Must include:
- question
- framework combination
- evidence / inference / hypothesis separation
- source quality notes when sources are used
- gaps
- conclusion

## Decision brief contract

Must include:
- decision to be made
- options
- criteria
- trade-offs
- risks
- recommended next validation step

## Action plan contract

Must include:
- objective
- 5W2H table
- RACI if owners matter
- dependencies
- success metric
- next action

## Social post contract

Must include:
- hook
- clear thesis
- compact structure
- examples or framework list
- closing statement
- no unsupported claims

## Repository generation contract

Must include:
- file tree
- SKILL.md
- references
- templates
- examples
- eval cases
- tests
- README
- install/run instructions
