# Framework Routing Rules

## Intent-first routing

Do not choose frameworks alphabetically. Choose by intent, complexity, risk, and delivery format.

## Default combinations

| User intent | Framework combination | Output |
|---|---|---|
| research / pesquisa | MECE + SCQA + evidence hierarchy | Executive research synthesis |
| decision / decidir | Cynefin + trade-off matrix + risk register | Decision brief |
| communication / comunicação | SCQA + AIDA + audience framing | Clear message or post |
| planning / planejamento | Working Backwards + 5W2H + RACI | Action plan |
| diagnosis / diagnóstico | 3P + Ishikawa + Theory of Constraints | Root-cause diagnostic |
| prioritization / priorizar | Eisenhower + impact/effort + Theory of Constraints | Priority matrix |
| product/customer | JTBD + Kano + User Story Mapping | Customer/product insight |
| strategy | First Principles + SWOT/PESTEL if requested + OKR/X-Matrix | Strategy map |
| rework/process | Value Stream Mapping + 3P + Theory of Constraints | Rework reduction map |
| execution handoff | 5W2H + RACI + Linear issue schema | Project/ticket plan |
| social post | SCQA + AIDA + one sharp thesis | Publishable narrative |
| repository/system design | Working Backwards + modular architecture + evals | Implementation-ready repo |

## Complexity routing

| Context | Prefer |
|---|---|
| clear / obvious task | 1–2 frameworks |
| complicated expert task | 2–3 frameworks |
| complex social/system task | Cynefin + hypothesis log + iterative plan |
| chaotic urgent task | triage first, then decide framework |
| high-stakes task | quality bar + human review + risk register |

## Combination limits

- Default: 2–3 frameworks.
- Complex execution: up to 5.
- Educational A-Z artifact: all frameworks allowed.
- Never add frameworks that do not change the output.

## Pre-balance trigger

Ask questions only if missing context will likely cause rework.

Ask no more than 5 questions. If the user asks to proceed, infer and label assumptions.

## Output size routing

| User signal | Output |
|---|---|
| "rápido", "curto", "só me diz" | 80–180 words |
| "post", "LinkedIn", "redes" | 150–400 words |
| "executivo", "decisão" | table + synthesis, 300–700 words |
| "profundo", "completo", "repo" | structured deep output |
| "JSON", "YAML", "CSV" | strict machine-readable output |
