# Pre-Balance Questionnaire

Use only when required.

## Standard version

1. Objective: What decision, output, or action should this support?
2. Audience: Who will read or use the output?
3. Depth: short, standard, or deep?
4. Evidence: provided data, web sources, internal docs, or assumptions?
5. Delivery: table, memo, plan, checklist, JSON, social post, or repo?

## Ultra-short version

```text
Antes de montar: isso é para decisão, comunicação, pesquisa ou execução? Qual público e qual formato final?
```

## Assumption fallback

If the user wants speed, proceed with assumptions:

| ID | Assumption | Impact |
|---|---|---|
| A-001 | Audience inferred as business/non-dev | Sets language simplicity |
| A-002 | Depth inferred as standard | Avoids excessive output |
| A-003 | Evidence inferred as user-provided context only | Avoids unsupported sourcing |
