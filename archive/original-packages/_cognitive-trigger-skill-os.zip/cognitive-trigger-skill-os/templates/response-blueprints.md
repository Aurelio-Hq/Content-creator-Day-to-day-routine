# Response Blueprints

## Blueprint — Executive Decision

```markdown
## Decision frame
| Option | Criteria | Risk | Evidence | Next validation |

## Recommended direction
[decision-support wording, not absolute certainty]

## Assumptions
| ID | Assumption | Why it matters |

## Next action
[one concrete action]
```

## Blueprint — Research

```markdown
## Research question
## Framework combination
## Findings
| Theme | Evidence | Confidence | Relevance |
## Gaps
## Synthesis
```

## Blueprint — Social Post

```markdown
[Hook]

[Thesis]

[Framework / list / example]

[Practical implication]

[Closing line]
```

## Blueprint — Action Plan

```markdown
## Objective
| 5W2H | Answer |
| RACI | Owner |
| Dependency | Before/After |
| Metric | Target |
```
