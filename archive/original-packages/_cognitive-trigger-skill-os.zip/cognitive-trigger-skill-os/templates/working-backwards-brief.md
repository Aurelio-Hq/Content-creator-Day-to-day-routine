# Working Backwards Brief

## Use when

- final artifact matters
- execution is expected
- the user asks for repository, project, sprint, plan, launch, deliverable, roadmap, or implementation

## Structure

| Field | Answer |
|---|---|
| End state | What should exist at the end? |
| User / audience | Who uses it? |
| Success criteria | How will quality be judged? |
| Required artifacts | What files, documents, outputs, or tickets are needed? |
| Constraints | Time, format, source, style, risk |
| Dependencies | What must come before what? |
| First action | What starts now? |
