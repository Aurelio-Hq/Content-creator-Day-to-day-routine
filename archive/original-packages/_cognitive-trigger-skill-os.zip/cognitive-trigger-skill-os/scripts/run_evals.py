"""Run lightweight eval checks for the Cognitive Framework Router."""

from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from framework_router import route_prompt


def main() -> int:
    cases = json.loads((ROOT / "evals" / "eval_cases.json").read_text(encoding="utf-8"))
    failures = []
    for case in cases:
        route = route_prompt(case["prompt"])
        expected_intent = case.get("expected_intent")
        expected_frameworks = case.get("expected_frameworks", [])
        should_trigger = case["should_trigger"]

        triggered = route.intent not in {"insufficient_context", "simple_factual"} and not route.ask_pre_balance
        if case.get("allow_pre_balance"):
            triggered = True

        if should_trigger and not triggered:
            failures.append((case["id"], "expected trigger", route.intent))
        if not should_trigger and triggered:
            failures.append((case["id"], "expected non-trigger", route.intent))
        if expected_intent and route.intent != expected_intent:
            failures.append((case["id"], f"expected intent {expected_intent}", route.intent))
        for fw in expected_frameworks:
            if fw not in route.frameworks:
                failures.append((case["id"], f"missing framework {fw}", route.frameworks))

    if failures:
        print("FAIL")
        for failure in failures:
            print(failure)
        return 1

    print(f"PASS: {len(cases)} eval cases")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
