"""Simple deterministic helper for testing the Cognitive Framework Router skill.

This is not the skill itself. It is a lightweight routing reference used by tests/evals.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Dict


@dataclass(frozen=True)
class Route:
    intent: str
    frameworks: List[str]
    output_contract: str
    ask_pre_balance: bool = False
    working_backwards: bool = False


FRAMEWORKS: Dict[str, str] = {
    "A": "AIDA",
    "B": "Balanced Scorecard",
    "C": "Cynefin",
    "D": "Double Diamond",
    "E": "Eisenhower Matrix",
    "F": "First Principles",
    "G": "GROW",
    "H": "Hoshin Kanri",
    "I": "Ishikawa / Fishbone",
    "J": "Jobs to Be Done",
    "K": "Kano Model",
    "L": "Lean Canvas",
    "M": "MECE",
    "N": "North Star Metric",
    "O": "OKR",
    "P": "3P — Problem, Process, Progress",
    "Q": "QFD",
    "R": "RACI",
    "S": "SCQA",
    "T": "Theory of Constraints",
    "U": "User Story Mapping",
    "V": "Value Stream Mapping",
    "W": "5W2H",
    "X": "X-Matrix",
    "Y": "Yamazumi Chart",
    "Z": "Zachman Framework",
}


def _has_any(text: str, words: List[str]) -> bool:
    lower = text.lower()
    return any(word.lower() in lower for word in words)


def route_prompt(prompt: str) -> Route:
    """Return the recommended framework combination for a prompt."""
    p = prompt.lower().strip()
    if not p:
        return Route(
            intent="insufficient_context",
            frameworks=[],
            output_contract="pre_balance_questionnaire",
            ask_pre_balance=True,
        )

    # Simple factual questions should not trigger framework routing.
    if _has_any(p, ["capital da frança", "quanto é", "que horas", "what time"]):
        return Route(intent="simple_factual", frameworks=[], output_contract="direct_answer")

    execution = _has_any(p, ["repo", "repositório", "sprint", "linear", "plano de ação", "executar", "projeto", "tarefas"])
    if execution:
        return Route(
            intent="execution",
            frameworks=["Working Backwards", "5W2H", "RACI"],
            output_contract="action_plan_or_repository",
            working_backwards=True,
        )

    if _has_any(p, ["decisão", "decidir", "trade-off", "opções", "escolher", "priorizar"]):
        return Route(
            intent="decision",
            frameworks=["Cynefin", "Trade-off Matrix", "Risk Register"],
            output_contract="decision_brief",
        )

    if _has_any(p, ["pesquisa", "research", "fontes", "evidência", "evidencias", "validar"]):
        return Route(
            intent="research",
            frameworks=["MECE", "SCQA", "Evidence hierarchy"],
            output_contract="research_synthesis",
        )

    if _has_any(p, ["comunicação", "post", "linkedin", "copy", "mensagem", "apresentação", "pitch"]):
        return Route(
            intent="communication",
            frameworks=["SCQA", "AIDA", "Audience Framing"],
            output_contract="communication_asset",
        )

    if _has_any(p, ["diagnóstico", "causa", "retrabalho", "gargalo", "processo", "dor"]):
        return Route(
            intent="diagnosis",
            frameworks=["3P — Problem, Process, Progress", "Ishikawa / Fishbone", "Theory of Constraints"],
            output_contract="diagnostic_brief",
        )

    if _has_any(p, ["produto", "cliente", "icp", "jornada", "valor"]):
        return Route(
            intent="product_customer",
            frameworks=["Jobs to Be Done", "Kano Model", "User Story Mapping"],
            output_contract="product_insight",
        )

    if len(p.split()) <= 4:
        return Route(
            intent="underspecified",
            frameworks=[],
            output_contract="pre_balance_questionnaire",
            ask_pre_balance=True,
        )

    return Route(
        intent="general_structuring",
        frameworks=["MECE", "SCQA"],
        output_contract="structured_response",
    )


def minimum_quality_bar(prompt: str) -> Dict[str, str]:
    """Infer a minimal output shape from user signals."""
    p = prompt.lower()
    if _has_any(p, ["curto", "rápido", "só", "simples"]):
        return {"depth": "short", "format": "bullets", "target_words": "80-180"}
    if _has_any(p, ["post", "linkedin", "redes"]):
        return {"depth": "medium", "format": "social_post", "target_words": "150-400"}
    if _has_any(p, ["json", "yaml", "csv"]):
        return {"depth": "strict", "format": "machine_readable", "target_words": "as needed"}
    if _has_any(p, ["repo", "repositório", "completo", "profundo"]):
        return {"depth": "deep", "format": "architecture_artifact", "target_words": "as needed"}
    return {"depth": "standard", "format": "table_first", "target_words": "300-700"}
