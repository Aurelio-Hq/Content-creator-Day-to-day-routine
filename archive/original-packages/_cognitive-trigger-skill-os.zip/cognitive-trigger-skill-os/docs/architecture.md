# Architecture

## Macro view

```text
Natural user request
→ trigger detection
→ pre-balance questionnaire if needed
→ 4D quality bar
→ 5D operational matrix
→ framework-combination routing
→ output contract
→ discernment check
→ delivery
→ diligence / human review when required
```

## Why one main skill

This repo intentionally uses one main Claude Skill because the first product is a cognitive routing layer, not a full agent team. The skill can later delegate to subagents or additional skills, but the MVP should prove the routing logic first.

## When to split into more skills

Split later if:
- research normalization becomes large;
- delivery generation needs many artifact formats;
- Linear/project generation requires tool permissions;
- FAQ/onboarding becomes a customer-facing product;
- simulation requires dedicated scripts or data.

## Minimum viable repo

The MVP repo needs:
- SKILL.md
- A-Z framework catalog
- routing rules
- templates
- examples
- evals
- tests
