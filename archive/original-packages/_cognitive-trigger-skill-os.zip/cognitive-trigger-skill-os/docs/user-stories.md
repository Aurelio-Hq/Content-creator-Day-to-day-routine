# User Stories

## US-001 — Framework routing

As a non-dev user, I want to type "pesquisa" or "decisão" so that Claude selects the right combination of frameworks without requiring me to know the methodology.

## US-002 — Pre-balance questionnaire

As a user, I want Claude to ask only the minimum necessary questions so that I do not waste time filling a long form.

## US-003 — Working backwards

As a builder, I want Claude to start from the final artifact so that the plan and repo are not random.

## US-004 — Executive clarity

As a content/business operator, I want outputs to have the minimum viable structure, length, and format so that I can use them directly.

## US-005 — Evals

As a maintainer, I want test cases that verify triggers, edge cases, and non-triggers so that the skill does not activate incorrectly.
