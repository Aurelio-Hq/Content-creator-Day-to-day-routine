# Eval Guide

## Eval objective

Test whether the skill:
1. activates on the right prompts;
2. avoids activation on unrelated prompts;
3. selects combinations, not isolated frameworks;
4. asks pre-balance questions only when needed;
5. respects output length and format signals.

## Case types

Each eval case includes:
- obvious trigger
- edge case
- non-trigger

## Local runner

```bash
python scripts/run_evals.py
python -m unittest discover -s tests
```

## Manual Claude Console eval

Use variables:
- {{user_prompt}}
- {{expected_behavior}}

Check:
- activation
- framework combination
- pre-balance behavior
- output contract
- risk / review notes
