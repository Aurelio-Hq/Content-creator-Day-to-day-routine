# Dependency Map

```text
user_request
→ trigger_detection
→ pre_balance_questionnaire?
→ quality_bar_4d_5d
→ framework_combination
→ output_contract
→ quality_check
→ final_delivery
```

## Hard review gates

| Gate | Trigger | Required behavior |
|---|---|---|
| G1 | Insufficient context | Ask pre-balance questions or label assumptions |
| G2 | Prioritization / decision | Add criteria and human review note |
| G3 | Execution plan | Add dependencies and owners |
| G4 | External/public deliverable | Add QA checklist |
| G5 | Critical / high-stakes output | Require human review |
| G6 | External effect / irreversible action | Require explicit confirmation |
