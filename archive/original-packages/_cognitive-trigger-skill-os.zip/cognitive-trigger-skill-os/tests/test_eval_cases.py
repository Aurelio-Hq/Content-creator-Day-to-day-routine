import json
import unittest
from pathlib import Path


class TestEvalCases(unittest.TestCase):
    def test_eval_cases_have_required_fields(self):
        root = Path(__file__).resolve().parents[1]
        cases = json.loads((root / "evals" / "eval_cases.json").read_text(encoding="utf-8"))
        self.assertGreaterEqual(len(cases), 6)
        for case in cases:
            self.assertIn("id", case)
            self.assertIn("prompt", case)
            self.assertIn("should_trigger", case)
            self.assertIn("expected_frameworks", case)
            self.assertIn("expected_behavior", case)

    def test_has_trigger_edge_and_non_trigger(self):
        root = Path(__file__).resolve().parents[1]
        cases = json.loads((root / "evals" / "eval_cases.json").read_text(encoding="utf-8"))
        self.assertTrue(any(c["should_trigger"] for c in cases))
        self.assertTrue(any(not c["should_trigger"] for c in cases))
        self.assertTrue(any(c.get("allow_pre_balance") for c in cases))


if __name__ == "__main__":
    unittest.main()
