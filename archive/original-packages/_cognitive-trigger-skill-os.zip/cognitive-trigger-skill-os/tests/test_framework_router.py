import unittest
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from framework_router import route_prompt, minimum_quality_bar


class TestFrameworkRouter(unittest.TestCase):
    def test_research_route(self):
        route = route_prompt("Faça uma pesquisa sobre IA generativa na educação e devolva um resumo executivo.")
        self.assertEqual(route.intent, "research")
        self.assertIn("MECE", route.frameworks)
        self.assertIn("SCQA", route.frameworks)

    def test_decision_route(self):
        route = route_prompt("Preciso decidir entre lançar agora ou validar mais.")
        self.assertEqual(route.intent, "decision")
        self.assertIn("Cynefin", route.frameworks)

    def test_execution_route_uses_working_backwards(self):
        route = route_prompt("Crie um repositório completo com SKILL.md, evals e testes.")
        self.assertEqual(route.intent, "execution")
        self.assertTrue(route.working_backwards)
        self.assertIn("Working Backwards", route.frameworks)

    def test_pre_balance_for_vague_prompt(self):
        route = route_prompt("melhora isso")
        self.assertTrue(route.ask_pre_balance)

    def test_quality_bar_social_post(self):
        qb = minimum_quality_bar("Crie um post para LinkedIn")
        self.assertEqual(qb["format"], "social_post")


if __name__ == "__main__":
    unittest.main()
