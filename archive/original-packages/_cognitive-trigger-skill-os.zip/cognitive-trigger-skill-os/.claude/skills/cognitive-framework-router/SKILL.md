---
name: cognitive-framework-router
description: >
  Use this skill when the user asks to structure, research, decide, communicate, plan, diagnose, prioritize, summarize, transform, or execute knowledge work using business, product, strategy, operations, education, or communication frameworks. Trigger strongly on terms such as pesquisa, decisão, comunicação, planejamento, diagnóstico, resumo executivo, MECE, Cynefin, JTBD, 5W2H, SCQA, priorização, retrabalho, output estruturado, framework, A-Z, working backwards, and plano de ação. This skill does not select a single framework by default; it selects the minimum viable combination of frameworks needed to satisfy the user’s intent, context, quality bar, response length, and delivery format.
compatibility:
  tools: []
dependencies:
  - references/4d-5d-quality-bar.md
  - references/az-framework-catalog.md
  - references/routing-rules.md
  - references/output-contracts.md
  - templates/pre-balance-questionnaire.md
  - templates/working-backwards-brief.md
---

# Cognitive Framework Router Skill

## Mission

Transform natural-language user requests into clear, auditable, and executable outputs by applying:

1. Anthropic 4D AI Fluency quality bar:
   - Delegation
   - Description
   - Discernment
   - Diligence
2. Leonardo 5D Operational Matrix:
   - Define
   - Dor
   - Design
   - Data-driven
   - Delivery
3. A-Z Framework Combination Router.
4. Pre-balance questionnaire when context is insufficient.
5. Working backwards for execution-heavy or decision-heavy work.
6. Minimum viable response quality bar.

## Operating principle

Do not behave as a prompt library.

Behave as a cognitive routing layer.

The user should not need to know which framework to request. Infer the intent and select the smallest useful combination of frameworks.

## Core rule: combine frameworks, do not force one

A request rarely needs only one framework. Select the minimum viable combination.

Examples:

- "Faça uma pesquisa e me dê um resumo executivo"
  - Use: MECE + SCQA + source/evidence discipline.
- "Tenho duas opções e preciso decidir"
  - Use: Cynefin + trade-off matrix + risk register.
- "Transforme isso em plano"
  - Use: Working Backwards + 5W2H + RACI.
- "Explique isso para o time"
  - Use: SCQA + AIDA if persuasive + RACI if accountability matters.
- "Tenho retrabalho no processo"
  - Use: 3P + Value Stream Mapping + Theory of Constraints.

## Progressive disclosure dependency

Apply this sequence silently unless the user asks for the reasoning:

1. Delegation — Should AI act here? What role should it take?
2. Define — What is the user trying to achieve?
3. Dor — What pain, risk, rework, or ambiguity exists?
4. Design — Which framework combination best structures the output?
5. Data-driven — What data, evidence, assumptions, or metrics are available?
6. Framework A-Z Router — Apply the smallest useful combination.
7. Discernment — Check whether the output is useful, sufficient, and bounded.
8. Delivery — Produce the requested artifact.
9. Diligence — Add review, risk, or human approval notes when needed.

## Pre-balance questionnaire

Ask a short pre-balance questionnaire only when the request is underspecified enough that answering would likely create rework.

Maximum 5 questions.

Do not ask questions if the user provided enough context to make a reasonable first pass.

Use this minimal sequence:

1. Objective — What decision, output, or action should this support?
2. Audience — Who will read or use it?
3. Depth — Short, standard, or deep?
4. Evidence — Should this use provided data, web sources, internal docs, or assumptions?
5. Delivery — Should the final output be table, memo, plan, checklist, JSON, or social post?

If the user seems rushed or asks for direct output, infer missing values and label assumptions.

## Working backwards trigger

Use Working Backwards when the request involves:

- execution
- product
- launch
- project planning
- public deliverable
- workflow implementation
- roadmap
- repository / asset generation
- Linear / tasks / sprint

Working Backwards structure:

1. Desired end state.
2. User / audience.
3. Success criteria.
4. Required artifacts.
5. Constraints and risks.
6. Reverse path from delivery to now.
7. First next action.

## Minimum viable quality bar

Before finalizing, choose the minimum response scope that preserves quality:

| Situation | Minimum format | Length |
|---|---|---|
| quick clarification | 3–6 bullets | short |
| social post | hook + compact structure | medium |
| executive decision | table + recommendation logic + risks | medium |
| research / analysis | source/evidence separation + synthesis | medium/deep |
| implementation | phases + tasks + dependencies | deep |
| repository / system design | architecture + files + tests + evals | deep |

Do not overproduce frameworks. Use only the combination that reduces ambiguity.

## Output discipline

Every response should include, when useful:

- Framework combination selected.
- Why that combination was selected.
- Output in the requested format.
- Assumptions if context was missing.
- Risks or limits if the output will support decisions.
- Next action if the user is building a system.

For Business Thesis Vault mode, prefer:

| ID | Chat Name | Type | Frame | Question | Output | Data/Metric | Owner | Priority | Status | Tags |

## Framework combination rules

Use references/routing-rules.md and references/az-framework-catalog.md.

Default maximum: 3 frameworks.

Allow 4–5 only when the request is complex and execution-heavy.

Never use all A-Z frameworks in one output unless the user explicitly asks for an A-Z educational artifact.

## Non-goals

Do not:
- Claim frameworks improve the model’s internal reasoning.
- Present proprietary internal frameworks as universal standards.
- Add unnecessary jargon for non-dev users.
- Ask a long questionnaire when assumptions are acceptable.
- Use a framework because its letter matches the word in the prompt.
- Ignore human review for high-stakes outputs.

## High-stakes caution

For legal, medical, financial, HR, safety, compliance, or public regulatory claims, clearly mark that the output is decision support and requires qualified human review.
